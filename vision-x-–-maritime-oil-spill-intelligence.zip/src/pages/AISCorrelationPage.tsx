import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  GitBranch, 
  Filter, 
  Ship, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Compass, 
  ArrowRight, 
  ShieldAlert, 
  ChevronRight, 
  Info, 
  ExternalLink,
  SlidersHorizontal,
  X
} from 'lucide-react';
import { mockIncidents, mockCandidateVessels } from '../data/mockData';
import { CandidateVessel } from '../types';

export const AISCorrelationPage: React.FC = () => {
  const navigate = useNavigate();
  const incident = mockIncidents[0]; // Spill #001
  const [selectedVessel, setSelectedVessel] = useState<CandidateVessel>(mockCandidateVessels[0]);
  const [filterThreshold, setFilterThreshold] = useState<number>(30);

  const filteredVessels = mockCandidateVessels.filter(
    v => v.attributionScore >= filterThreshold
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight font-display flex items-center gap-2.5">
            AIS Vessel Correlation
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 text-xs font-mono font-normal border border-cyan-500/30">
              VESSEL RANKING & EXPLAINABILITY
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Shortlist and rank candidate vessels based on spatio-temporal proximity, trajectory intersection, and AIS anomalies.
          </p>
        </div>

        <button
          onClick={() => navigate('/vessel-attribution')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/20 cursor-pointer self-start sm:self-auto"
        >
          <span>Attribution Dossier</span>
          <ArrowRight className="w-4 h-4 text-slate-950" />
        </button>
      </div>

      {/* Incident Banner (Matches Reference Screenshot Top Card) */}
      <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-950/80 border border-red-500/40 flex items-center justify-center text-red-400 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold text-white font-display">Spill Event #001</span>
              <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 text-[10px] font-mono font-bold border border-red-500/40">
                ACTIVE INCIDENT
              </span>
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              Correlating with 27 AIS vessels tracked in Arabian Sea Sector
            </div>
          </div>
        </div>

        {/* 4 Metadata Badges matching reference */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div className="px-3 py-2 rounded-lg bg-[#050e1b] border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase">Detection Time</div>
            <div className="font-bold text-white text-[11px] mt-0.5">04 Sep 13:42 UTC</div>
          </div>
          <div className="px-3 py-2 rounded-lg bg-[#050e1b] border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase">Spill Location</div>
            <div className="font-bold text-cyan-300 text-[11px] mt-0.5">12.34°N, 68.75°E</div>
          </div>
          <div className="px-3 py-2 rounded-lg bg-[#050e1b] border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase">Estimated Area</div>
            <div className="font-bold text-white text-[11px] mt-0.5">12.4 km²</div>
          </div>
          <div className="px-3 py-2 rounded-lg bg-[#050e1b] border border-slate-800">
            <div className="text-[10px] text-slate-400 uppercase">Analysis Window</div>
            <div className="font-bold text-emerald-400 text-[11px] mt-0.5">±6 hours</div>
          </div>
        </div>
      </div>

      {/* Main Content Grid: Left Map + Right Candidate Vessels Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Vessel Trajectory & Spill Correlation Radar Map (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg flex flex-col h-full">
            <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider">
                Vessel Trajectory & Spill Correlation
              </span>
              <span className="text-[10px] font-mono text-cyan-400">Drift Corridor Active</span>
            </div>

            {/* Custom Radar Vector Map displaying Drift Corridor & Tracks */}
            <div className="w-full h-80 rounded-xl overflow-hidden border border-slate-800 relative bg-[#030914] select-none">
              <svg viewBox="0 0 500 400" className="w-full h-full">
                <defs>
                  <radialGradient id="aisMapSpill" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#ef4444" stopOpacity="0.9" />
                    <stop offset="40%" stopColor="#f97316" stopOpacity="0.75" />
                    <stop offset="80%" stopColor="#eab308" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity="0" />
                  </radialGradient>

                  <linearGradient id="aisDrift" x1="0%" y1="0%" x2="100%" y2="80%">
                    <stop offset="0%" stopColor="#ef4444" stopOpacity="0.5" />
                    <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.25" />
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.05" />
                  </linearGradient>
                </defs>

                {/* Ocean Background */}
                <rect width="500" height="400" fill="#040b17" />

                {/* Radar Grid Circles & Radials */}
                <g stroke="rgba(6, 182, 212, 0.1)" strokeWidth="0.8">
                  <circle cx="250" cy="200" r="60" fill="none" />
                  <circle cx="250" cy="200" r="120" fill="none" />
                  <circle cx="250" cy="200" r="180" fill="none" />
                  <line x1="250" y1="0" x2="250" y2="400" />
                  <line x1="0" y1="200" x2="500" y2="200" />
                </g>

                {/* Drift Corridor Envelope */}
                <polygon points="210,180 360,260 340,320 180,240" fill="url(#aisDrift)" />
                <text x="270" y="270" fill="#fdba74" fontSize="9" fontFamily="monospace" opacity="0.8">
                  Drift Corridor
                </text>

                {/* Spill Location Polygon */}
                <ellipse cx="230" cy="200" rx="36" ry="24" fill="url(#aisMapSpill)" className="animate-pulse" />
                <circle cx="230" cy="200" r="4" fill="#ffffff" />
                <circle cx="230" cy="200" r="14" fill="none" stroke="#ef4444" strokeWidth="1" strokeDasharray="3 3" />

                {/* MV Ocean Star Track (Red dashed gap + cyan arrows) */}
                <g>
                  {/* Pre-gap track */}
                  <line x1="120" y1="90" x2="180" y2="150" stroke="#38bdf8" strokeWidth="2" strokeDasharray="4 2" />
                  {/* Suspicious AIS Gap section */}
                  <line x1="180" y1="150" x2="245" y2="210" stroke="#ef4444" strokeWidth="2.5" strokeDasharray="3 3" />
                  {/* Post-gap track */}
                  <line x1="245" y1="210" x2="330" y2="280" stroke="#38bdf8" strokeWidth="2" />
                  <polygon points="334,284 322,279 326,289" fill="#38bdf8" />

                  {/* MV Ocean Star Target Inset */}
                  <g transform="translate(290, 190)">
                    <rect x="0" y="0" width="120" height="34" rx="4" fill="#081424" stroke="#ef4444" strokeWidth="1.2" />
                    <text x="6" y="14" fill="#ffffff" fontSize="10" fontWeight="bold">
                      MV Ocean Star
                    </text>
                    <text x="6" y="26" fill="#ef4444" fontSize="9" fontFamily="monospace">
                      IMO: 9527048 | 92%
                    </text>
                  </g>
                </g>

                {/* Other candidate ships */}
                {/* Coastal Trader */}
                <circle cx="290" cy="310" r="4" fill="#f59e0b" />
                <line x1="210" y1="280" x2="350" y2="330" stroke="#10b981" strokeWidth="1" strokeDasharray="4 2" opacity="0.6" />
                <text x="300" y="315" fill="#fde68a" fontSize="8">Coastal Trader</text>

                {/* Blue Horizon */}
                <circle cx="160" cy="270" r="4" fill="#38bdf8" />
                <line x1="80" y1="240" x2="220" y2="300" stroke="#64748b" strokeWidth="1" opacity="0.5" />
                <text x="170" y="275" fill="#bae6fd" fontSize="8">Blue Horizon</text>

                {/* Sea Pioneer */}
                <circle cx="340" cy="130" r="4" fill="#10b981" />
                <text x="350" y="135" fill="#a7f3d0" fontSize="8">Sea Pioneer</text>

                {/* Marlin */}
                <circle cx="390" cy="180" r="4" fill="#94a3b8" />
                <text x="400" y="185" fill="#cbd5e1" fontSize="8">Marlin</text>
              </svg>

              {/* Map Legend */}
              <div className="absolute bottom-2 left-2 right-2 bg-black/80 backdrop-blur-md p-2 rounded-lg border border-white/10 flex flex-wrap items-center justify-between text-[10px] font-mono text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-0.5 bg-cyan-400"></span> Vessel Track
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-red-500"></span> Spill Location
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span> AIS Vessel
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-1 bg-amber-500/40"></span> Drift Corridor
                </span>
              </div>
            </div>

            {/* Quick Metrics Bar below map */}
            <div className="grid grid-cols-2 gap-2 mt-3 pt-2 text-xs font-mono">
              <div className="p-2 rounded-lg bg-[#050e1b] border border-slate-800">
                <span className="text-slate-400 block text-[10px]">CORRELATION BUFFER</span>
                <span className="text-white font-bold">15 km Radius</span>
              </div>
              <div className="p-2 rounded-lg bg-[#050e1b] border border-slate-800">
                <span className="text-slate-400 block text-[10px]">DRIFT DRIFT RATE</span>
                <span className="text-cyan-300 font-bold">1.4 knots (115° SE)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Candidate Vessel Ranking Table + Explainability Drawer (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider">
                  Candidate Vessel Ranking
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  ({filteredVessels.length} targets shortlisted)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setFilterThreshold(filterThreshold === 30 ? 60 : 30)}
                  className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
                >
                  <Filter className="w-3 h-3 text-cyan-400" />
                  <span>Filter ({filterThreshold}%+)</span>
                </button>
              </div>
            </div>

            {/* Interactive Candidate Vessel Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                    <th className="py-2 px-2 font-semibold">Rank</th>
                    <th className="py-2 px-2 font-semibold">Vessel Name</th>
                    <th className="py-2 px-2 font-semibold">IMO</th>
                    <th className="py-2 px-2 font-semibold">Distance</th>
                    <th className="py-2 px-2 font-semibold">Time Match</th>
                    <th className="py-2 px-2 font-semibold">Track Match</th>
                    <th className="py-2 px-2 font-semibold">AIS Gap</th>
                    <th className="py-2 px-2 font-semibold text-right">Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {filteredVessels.map((v) => {
                    const isSelected = selectedVessel.name === v.name;
                    return (
                      <tr
                        key={v.name}
                        onClick={() => setSelectedVessel(v)}
                        className={`transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-cyan-950/40 text-cyan-200 font-semibold'
                            : 'hover:bg-slate-900/60 text-slate-300'
                        }`}
                      >
                        <td className="py-2.5 px-2">
                          <span
                            className={`w-5 h-5 rounded-full inline-flex items-center justify-center text-[10px] font-bold ${
                              v.rank === 1
                                ? 'bg-red-500 text-slate-950 shadow-sm shadow-red-500/50'
                                : v.rank === 2
                                ? 'bg-amber-500 text-slate-950'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {v.rank}
                          </span>
                        </td>
                        <td className="py-2.5 px-2 font-sans font-bold text-white whitespace-nowrap">
                          {v.name}
                        </td>
                        <td className="py-2.5 px-2 text-slate-400">{v.imo}</td>
                        <td className="py-2.5 px-2 font-bold text-slate-200">{v.distanceKm} km</td>
                        <td className="py-2.5 px-2 text-cyan-300">{v.timeMatchPct}%</td>
                        <td className="py-2.5 px-2 text-blue-300">{v.trackMatchPct}%</td>
                        <td className="py-2.5 px-2">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              v.aisGapMin > 0
                                ? 'bg-red-950 text-red-300 border border-red-500/30'
                                : 'text-slate-500'
                            }`}
                          >
                            {v.aisGapMin} min
                          </span>
                        </td>
                        <td className="py-2.5 px-2 text-right">
                          <span
                            className={`px-2 py-0.5 rounded text-xs font-extrabold ${
                              v.attributionScore >= 85
                                ? 'bg-red-950/80 text-red-300 border border-red-500/40'
                                : v.attributionScore >= 60
                                ? 'bg-amber-950/80 text-amber-300 border border-amber-500/40'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {v.attributionScore}%
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* "Why this vessel?" Explainability Panel (Matches Reference Screenshot bottom right) */}
          <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
              <span className="text-xs font-bold text-white font-display flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-cyan-400" />
                Why this vessel? — Explainability Breakdown
              </span>
              <span className="text-[10px] font-mono text-cyan-400">
                Selected: {selectedVessel.name}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              {/* Vessel Mini Profile (4 Cols) */}
              <div className="md:col-span-5 p-3 rounded-lg bg-[#050e1b] border border-slate-800 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-white text-sm">{selectedVessel.name}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                      selectedVessel.attributionScore >= 85 ? 'bg-red-950 text-red-300' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {selectedVessel.attributionScore}% Score
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-slate-400 space-y-0.5">
                    <div>MMSI: {selectedVessel.mmsi}</div>
                    <div>Flag: {selectedVessel.flag} ({selectedVessel.flagCode})</div>
                    <div>Type: {selectedVessel.type}</div>
                    <div>Speed: {selectedVessel.lastReportedSpeed}</div>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-800">
                  <div className="text-[10px] text-amber-300 font-mono leading-tight">
                    ⚠ {selectedVessel.anomalyDetected}
                  </div>
                </div>
              </div>

              {/* Explainability Checkmarks List (7 Cols) */}
              <div className="md:col-span-7 flex flex-col justify-between">
                <div className="space-y-1.5 text-xs text-slate-300">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Spatial proximity ({selectedVessel.distanceKm} km from origin)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Temporal match ({selectedVessel.timeMatchPct}% overlap)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Trajectory compatibility ({selectedVessel.trackMatchPct}%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Drift-consistent displacement correlation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0 ${
                      selectedVessel.aisGapMin > 0 ? 'bg-red-500 text-slate-950' : 'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      {selectedVessel.aisGapMin > 0 ? '!' : '✓'}
                    </span>
                    <span className={selectedVessel.aisGapMin > 0 ? 'text-red-300 font-semibold' : ''}>
                      AIS transponder gap: {selectedVessel.aisGapMin} min during spill event
                    </span>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-end gap-3">
                  <button
                    onClick={() => navigate('/vessel-attribution')}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-all shadow-md cursor-pointer"
                  >
                    <span>View Evidence & Attribution</span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-950" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
