import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  AlertTriangle, 
  Ship, 
  Globe, 
  Activity, 
  CheckCircle2, 
  ArrowUpRight, 
  ExternalLink, 
  TrendingUp, 
  Clock, 
  Scan, 
  ShieldCheck, 
  Radio, 
  Layers,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { NauticalMap } from '../components/visuals/NauticalMap';
import { mockIncidents, mockCandidateVessels, mockDetectionsTrend } from '../data/mockData';
import { CandidateVessel, SpillIncident } from '../types';

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const [selectedIncident, setSelectedIncident] = useState<SpillIncident>(mockIncidents[0]);
  const [selectedVessel, setSelectedVessel] = useState<CandidateVessel | null>(mockCandidateVessels[0]);

  return (
    <div className="space-y-6">
      {/* Top Banner / Operational Status Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight font-display flex items-center gap-2.5">
            Global Oil Spill Intelligence
            <span className="px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 text-xs font-mono font-normal border border-cyan-500/30">
              LIVE SATELLITE RADAR
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time multi-spectral monitoring, synthetic aperture radar (SAR) detection, and automated AIS vessel correlation.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto">
          <button
            onClick={() => navigate('/satellite-analysis')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs transition-all shadow-md shadow-cyan-500/20 cursor-pointer"
          >
            <Scan className="w-3.5 h-3.5" />
            <span>Launch SAR Workspace</span>
          </button>
        </div>
      </div>

      {/* KPI Cards (Matches Reference Screenshots) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* 1. Oil Spills Detected */}
        <div 
          onClick={() => navigate('/satellite-analysis')}
          className="p-4 rounded-xl bg-[#091527] border border-red-500/30 hover:border-red-500/60 transition-all cursor-pointer group shadow-lg"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="font-semibold text-slate-300">Oil Spills Detected</span>
            <div className="w-7 h-7 rounded-lg bg-red-950/80 border border-red-500/40 flex items-center justify-center text-red-400 group-hover:scale-110 transition-transform">
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-display">3</span>
            <span className="text-[11px] font-mono text-red-400 font-semibold">+1 new today</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Last 24 hrs active</div>
        </div>

        {/* 2. Vessels Tracked */}
        <div 
          onClick={() => navigate('/ais-correlation')}
          className="p-4 rounded-xl bg-[#091527] border border-blue-500/30 hover:border-blue-500/60 transition-all cursor-pointer group shadow-lg"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="font-semibold text-slate-300">Total Vessels Tracked</span>
            <div className="w-7 h-7 rounded-lg bg-blue-950/80 border border-blue-500/40 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
              <Ship className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-display">27</span>
            <span className="text-[11px] font-mono text-cyan-400 font-semibold">+5 candidate</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Real-time AIS feeds</div>
        </div>

        {/* 3. Area Monitored */}
        <div className="p-4 rounded-xl bg-[#091527] border border-emerald-500/30 hover:border-emerald-500/60 transition-all group shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="font-semibold text-slate-300">Area Monitored</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
              <Globe className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-display">12.4 M</span>
            <span className="text-xs font-mono text-slate-400 font-bold">km²</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Global EEZ + Arabian Sea</div>
        </div>

        {/* 4. Model Confidence */}
        <div 
          onClick={() => navigate('/analytics')}
          className="p-4 rounded-xl bg-[#091527] border border-cyan-500/30 hover:border-cyan-500/60 transition-all cursor-pointer group shadow-lg"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span className="font-semibold text-slate-300">Model Confidence</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center text-cyan-300 group-hover:scale-110 transition-transform">
              <Activity className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-display">94.3%</span>
            <span className="text-[11px] font-mono text-emerald-400 font-semibold">+2.1% tuned</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">MobileNetV3 SAR-Net</div>
        </div>
      </div>

      {/* Main Interactive Maritime Map */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-300 font-semibold">
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
            <span>Operational Situational Map (Indian Ocean / Arabian Sea Sector)</span>
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="hidden sm:inline">Click markers for details</span>
            <span className="text-cyan-400 font-mono text-[11px]">Active Zone: Spill #001</span>
          </div>
        </div>

        <NauticalMap
          heightClass="h-[480px]"
          onSelectSpill={(s) => setSelectedIncident(s)}
          onSelectVessel={(v) => setSelectedVessel(v)}
        />
      </div>

      {/* Bottom 4 Cards (Matches Reference Screenshot Below Map) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Latest Detection */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider">
                Latest Detection
              </span>
              <span className="px-1.5 py-0.5 rounded bg-red-950 text-red-300 text-[10px] font-mono font-bold border border-red-500/40">
                HIGH SEVERITY
              </span>
            </div>

            <div className="flex items-center gap-3 my-2">
              {/* Mini Heatmap Thumbnail */}
              <div className="w-16 h-14 rounded-lg bg-[#040c17] border border-red-500/40 overflow-hidden relative shrink-0 flex items-center justify-center">
                <div className="w-8 h-8 rounded-full bg-red-500/80 blur-xs" />
                <div className="w-4 h-4 rounded-full bg-yellow-400/90 blur-xs absolute" />
                <span className="absolute bottom-0.5 right-0.5 text-[8px] font-mono text-cyan-300 bg-black/70 px-1 rounded">
                  SAR
                </span>
              </div>
              <div>
                <div className="text-sm font-bold text-white font-display">Incident #001</div>
                <div className="text-xs text-red-400 font-mono font-semibold">12.4 km² • 96.7% Conf</div>
                <div className="text-[10px] text-slate-400 font-mono">12.34°N, 68.75°E</div>
              </div>
            </div>

            <div className="text-[10px] font-mono text-slate-400 mt-1">
              Captured: 04 Sep 2026 13:42 UTC
            </div>
          </div>

          <button
            onClick={() => navigate('/satellite-analysis')}
            className="mt-3 w-full py-1.5 rounded-lg bg-cyan-950/70 hover:bg-cyan-900/80 border border-cyan-500/40 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <span>Analyze SAR Overlay</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 2. System Performance */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider">
                System Performance
              </span>
              <span className="text-[10px] font-mono text-cyan-400">Model v4.2</span>
            </div>

            <div className="flex items-center gap-4 my-2">
              {/* Circular Gauge */}
              <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="32" cy="32" r="26" stroke="#13263f" strokeWidth="5" fill="none" />
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    stroke="#06b6d4"
                    strokeWidth="5"
                    strokeDasharray={163.3}
                    strokeDashoffset={163.3 * (1 - 0.943)}
                    strokeLinecap="round"
                    fill="none"
                    style={{ filter: 'drop-shadow(0 0 6px #06b6d4)' }}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-xs font-bold text-white font-mono">94.3%</span>
                </div>
              </div>

              {/* Stats column */}
              <div className="space-y-1 text-xs font-mono">
                <div className="flex justify-between gap-4 text-slate-300">
                  <span className="text-slate-400">Precision:</span>
                  <span className="text-emerald-400 font-bold">91.2%</span>
                </div>
                <div className="flex justify-between gap-4 text-slate-300">
                  <span className="text-slate-400">Recall:</span>
                  <span className="text-cyan-300 font-bold">87.6%</span>
                </div>
                <div className="flex justify-between gap-4 text-slate-300">
                  <span className="text-slate-400">Latency:</span>
                  <span className="text-slate-200">1.82s</span>
                </div>
              </div>
            </div>
          </div>

          <div className="text-[10px] text-slate-400 border-t border-slate-800/80 pt-2 font-mono">
            SAR segmentation verified against coastal ground-truth.
          </div>
        </div>

        {/* 3. Spills Detected Trend (7-day bar chart) */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider">
                Spills Detected (Last 7 Days)
              </span>
              <span className="text-[10px] font-mono text-cyan-300">12 Total</span>
            </div>

            {/* Custom SVG Mini Bar Chart */}
            <div className="h-20 w-full mt-2">
              <svg viewBox="0 0 240 70" className="w-full h-full overflow-visible">
                {/* Horizontal Guide Lines */}
                <line x1="0" y1="15" x2="240" y2="15" stroke="#1e293b" strokeWidth="0.8" strokeDasharray="2 2" />
                <line x1="0" y1="40" x2="240" y2="40" stroke="#1e293b" strokeWidth="0.8" strokeDasharray="2 2" />
                <line x1="0" y1="65" x2="240" y2="65" stroke="#334155" strokeWidth="1" />

                {/* Bars */}
                {mockDetectionsTrend.map((d, idx) => {
                  const barWidth = 18;
                  const x = 12 + idx * 29;
                  const maxCount = 4;
                  const barHeight = (d.count / maxCount) * 50;
                  const y = 65 - barHeight;

                  return (
                    <g key={d.date}>
                      <rect
                        x={x}
                        y={y}
                        width={barWidth}
                        height={Math.max(4, barHeight)}
                        rx="3"
                        fill={d.count >= 3 ? '#06b6d4' : '#0284c7'}
                        className="transition-all hover:fill-cyan-300"
                        style={{
                          filter: d.count >= 3 ? 'drop-shadow(0 0 4px rgba(6,182,212,0.6))' : 'none'
                        }}
                      />
                      <text
                        x={x + barWidth / 2}
                        y="76"
                        textAnchor="middle"
                        fill="#64748b"
                        fontSize="8"
                        fontFamily="monospace"
                      >
                        {d.date.split(' ')[0]}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>

          <div className="text-[10px] text-slate-400 font-mono mt-2 flex items-center justify-between">
            <span>Peak: 04 Sep (3 alerts)</span>
            <span className="text-emerald-400">+33% weekly rate</span>
          </div>
        </div>

        {/* 4. Recent Incidents list */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 flex flex-col justify-between shadow-lg">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider">
                Recent Incidents
              </span>
              <button
                onClick={() => navigate('/alerts')}
                className="text-[10px] text-cyan-400 hover:underline"
              >
                View All
              </button>
            </div>

            <div className="space-y-2 mt-2">
              {mockIncidents.map((incident) => (
                <div
                  key={incident.id}
                  onClick={() => navigate('/investigation-report')}
                  className="p-2 rounded-lg bg-[#050e1a] border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer flex items-center justify-between text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-slate-200 truncate flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                      {incident.code} • {incident.areaKm2} km²
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono truncate">
                      {incident.detectionTime.split(' ')[0]} {incident.detectionTime.split(' ')[1]}
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 font-mono ${
                      incident.severity === 'High'
                        ? 'bg-red-950 text-red-300 border border-red-500/40'
                        : incident.severity === 'Medium'
                        ? 'bg-amber-950 text-amber-300 border border-amber-500/40'
                        : 'bg-blue-950 text-blue-300 border border-blue-500/40'
                    }`}
                  >
                    {incident.severity}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => navigate('/ais-correlation')}
            className="mt-3 w-full py-1.5 rounded-lg bg-blue-950/60 hover:bg-blue-900/80 border border-blue-500/40 text-blue-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <span>Proceed to AIS Correlation</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
