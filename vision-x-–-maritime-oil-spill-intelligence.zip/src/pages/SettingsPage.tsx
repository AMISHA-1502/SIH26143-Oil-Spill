import React, { useState } from 'react';
import { 
  Settings, 
  Sliders, 
  Bell, 
  Shield, 
  Database, 
  Cpu, 
  Map, 
  Save, 
  Check, 
  RotateCcw,
  User,
  Radio,
  ExternalLink,
  Layers,
  Sparkles
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const [confidenceThreshold, setConfidenceThreshold] = useState(80);
  const [timeWindowHours, setTimeWindowHours] = useState(6);
  const [aisGapThresholdMin, setAisGapThresholdMin] = useState(30);
  const [selectedModel, setSelectedModel] = useState('MobileNetV3-Custom');
  
  // Layer toggles
  const [layers, setLayers] = useState({
    spills: true,
    ais: true,
    drift: true,
    shippingLanes: true,
    restrictedZones: true,
  });

  // Notification toggles
  const [notifications, setNotifications] = useState({
    highSpills: true,
    vesselAttribution: true,
    aisGaps: true,
    emailDigest: false,
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight font-display flex items-center gap-2.5">
            Settings & System Configuration
            <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 text-xs font-mono border border-slate-700">
              CONSOLE PREFERENCES
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Configure AI segmentation thresholds, AIS temporal windows, ingestion pipelines, and alert routing.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto">
          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/20 cursor-pointer"
          >
            {savedSuccess ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
            <span>{savedSuccess ? 'Settings Saved' : 'Save Preferences'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: AI Model & Detection Thresholds (7 Cols) */}
        <div className="md:col-span-7 space-y-6">
          {/* AI Model Settings Card */}
          <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-white font-display uppercase tracking-wider flex items-center gap-2">
                <Cpu className="w-4 h-4 text-cyan-400" />
                AI Inference & Model Tuning
              </span>
              <span className="text-[10px] font-mono text-cyan-400">MobileNetV3 SAR-Net</span>
            </div>

            {/* Model Architecture Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 font-mono">
                Active Segmentation Model Architecture
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                {[
                  { id: 'MobileNetV3-Custom', name: 'MobileNetV3 (Custom)', desc: 'Fast inference (1.8s), edge-optimized' },
                  { id: 'ResNet50-SAR', name: 'ResNet-50 SAR', desc: 'High resolution, 2.8s inference' },
                  { id: 'UNet-DualPol', name: 'UNet Dual-Pol', desc: 'VV + VH co-polarization model' },
                ].map((m) => (
                  <div
                    key={m.id}
                    onClick={() => setSelectedModel(m.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      selectedModel === m.id
                        ? 'bg-cyan-950/60 border-cyan-500/80 text-white'
                        : 'bg-[#050e1b] border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-xs font-sans">{m.name}</div>
                    <div className="text-[10px] text-slate-400 mt-1 leading-tight">{m.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Confidence Threshold Slider */}
            <div className="pt-2">
              <div className="flex items-center justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-300">Minimum Spill Confidence Threshold</span>
                <span className="font-bold text-cyan-300">{confidenceThreshold}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="95"
                step="1"
                value={confidenceThreshold}
                onChange={(e) => setConfidenceThreshold(Number(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>50% (High Recall)</span>
                <span>80% (Recommended)</span>
                <span>95% (Zero False Positives)</span>
              </div>
            </div>

            {/* Temporal Window Slider */}
            <div className="pt-2">
              <div className="flex items-center justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-300">AIS Temporal Analysis Correlation Window</span>
                <span className="font-bold text-cyan-300">±{timeWindowHours} hours</span>
              </div>
              <input
                type="range"
                min="2"
                max="24"
                step="1"
                value={timeWindowHours}
                onChange={(e) => setTimeWindowHours(Number(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>±2 hrs</span>
                <span>±6 hrs (Standard)</span>
                <span>±24 hrs (Long Drift)</span>
              </div>
            </div>

            {/* AIS Blackout Sensitivity */}
            <div className="pt-2">
              <div className="flex items-center justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-300">AIS Transponder Gap Anomaly Trigger</span>
                <span className="font-bold text-red-400">&gt; {aisGapThresholdMin} min</span>
              </div>
              <input
                type="range"
                min="10"
                max="120"
                step="5"
                value={aisGapThresholdMin}
                onChange={(e) => setAisGapThresholdMin(Number(e.target.value))}
                className="w-full accent-red-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>10 min</span>
                <span>30 min (Flagged)</span>
                <span>120 min</span>
              </div>
            </div>
          </div>

          {/* Map Layer Defaults Card */}
          <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-white font-display uppercase tracking-wider flex items-center gap-2">
                <Map className="w-4 h-4 text-cyan-400" />
                Default Situational Map Layers
              </span>
              <span className="text-[10px] font-mono text-slate-400">Layer Preferences</span>
            </div>

            <div className="space-y-2.5 text-xs text-slate-300">
              {[
                { key: 'spills' as const, label: 'Oil Spill SAR Segmentation Masks (Polygons & Coordinates)' },
                { key: 'ais' as const, label: 'Live AIS Vessel Tracks & Position Vectors' },
                { key: 'drift' as const, label: 'Hydrodynamic Ocean Current Drift Projections (NOAA HYCOM)' },
                { key: 'shippingLanes' as const, label: 'International Maritime Commercial Shipping Corridors' },
                { key: 'restrictedZones' as const, label: 'Marine Protected Areas (MPA) & Exclusive Economic Zones (EEZ)' },
              ].map((item) => (
                <label key={item.key} className="flex items-center justify-between p-2.5 rounded-lg bg-[#050e1a] border border-slate-800 cursor-pointer hover:border-slate-700">
                  <span>{item.label}</span>
                  <input
                    type="checkbox"
                    checked={layers[item.key]}
                    onChange={(e) => setLayers(prev => ({ ...prev, [item.key]: e.target.checked }))}
                    className="w-4 h-4 accent-cyan-500 cursor-pointer"
                  />
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: User Profile & Integrations (5 Cols) */}
        <div className="md:col-span-5 space-y-6">
          {/* Operator Profile Card */}
          <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl space-y-3">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 font-bold text-lg">
                AM
              </div>
              <div>
                <div className="font-bold text-white text-sm">Amisha (Team Lead)</div>
                <div className="text-xs text-cyan-400 font-mono">Senior Maritime Analyst</div>
                <div className="text-[10px] text-slate-400 font-mono">Team VISION X • SIH 2026</div>
              </div>
            </div>

            <div className="space-y-2 text-xs font-mono text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Email:</span>
                <span className="text-white">amisha@teamvisionx.in</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Role:</span>
                <span className="text-cyan-300">Investigative Authority</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Problem ID:</span>
                <span className="text-emerald-400 font-bold">PS26143</span>
              </div>
            </div>
          </div>

          {/* External Data Connections Card */}
          <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl space-y-3">
            <div className="text-xs font-bold text-white font-display uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-800">
              <Database className="w-4 h-4 text-cyan-400" />
              Connected Data Ingestion Pipelines
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="p-2.5 rounded-lg bg-[#050e1a] border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-white font-bold">ESA Sentinel-1 SAR Hub</div>
                  <div className="text-[10px] text-slate-400">C-Band Synthetic Aperture Radar</div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                  ONLINE
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-[#050e1a] border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-white font-bold">MarineTraffic AIS Feed</div>
                  <div className="text-[10px] text-slate-400">Real-time Class A & B AIS Stream</div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                  ONLINE
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-[#050e1a] border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-white font-bold">NOAA HYCOM Currents</div>
                  <div className="text-[10px] text-slate-400">Global Ocean Circulation Drift Model</div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                  ONLINE
                </span>
              </div>
            </div>
          </div>

          {/* Notification Alerts Routing Card */}
          <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl space-y-3">
            <div className="text-xs font-bold text-white font-display uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-800">
              <Bell className="w-4 h-4 text-cyan-400" />
              Alert Subscriptions & Notifications
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <label className="flex items-center justify-between p-2 rounded bg-[#050e1a] border border-slate-800 cursor-pointer">
                <span>Instant High Severity Spill Alerts</span>
                <input
                  type="checkbox"
                  checked={notifications.highSpills}
                  onChange={(e) => setNotifications(prev => ({ ...prev, highSpills: e.target.checked }))}
                  className="accent-cyan-500"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded bg-[#050e1a] border border-slate-800 cursor-pointer">
                <span>Vessel Attribution &gt; 85% Alerts</span>
                <input
                  type="checkbox"
                  checked={notifications.vesselAttribution}
                  onChange={(e) => setNotifications(prev => ({ ...prev, vesselAttribution: e.target.checked }))}
                  className="accent-cyan-500"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded bg-[#050e1a] border border-slate-800 cursor-pointer">
                <span>AIS Transponder Blackout Alerts</span>
                <input
                  type="checkbox"
                  checked={notifications.aisGaps}
                  onChange={(e) => setNotifications(prev => ({ ...prev, aisGaps: e.target.checked }))}
                  className="accent-cyan-500"
                />
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
