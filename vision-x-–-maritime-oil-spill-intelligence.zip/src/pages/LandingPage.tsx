import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  ArrowRight, 
  Play, 
  Satellite, 
  GitBranch, 
  ShieldAlert, 
  Globe2, 
  ShieldCheck, 
  CheckCircle2,
  Ship,
  Sparkles,
  ExternalLink,
  ChevronRight,
  X
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const [showDemoModal, setShowDemoModal] = useState(false);

  return (
    <div className="min-h-screen bg-[#040914] text-slate-100 flex flex-col relative overflow-hidden">
      {/* Background Starfield and Ocean Gradient with trailing oil slick visual */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Ocean texture */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#061224]/90 via-[#040a17]/95 to-[#02060e]" />
        {/* Radial cyan glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-cyan-600/10 blur-[130px] rounded-full" />
      </div>

      {/* Top Navigation */}
      <header className="relative z-20 border-b border-cyan-500/20 bg-[#060e1b]/70 backdrop-blur-md px-6 lg:px-12 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center p-1.5 shadow-lg shadow-cyan-500/20">
            <svg viewBox="0 0 24 24" className="w-full h-full text-slate-950 stroke-current stroke-2 fill-none">
              <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
              <circle cx="12" cy="12" r="3" className="fill-cyan-100" />
            </svg>
          </div>
          <div>
            <div className="text-lg font-black tracking-wider text-white font-display">VISION X</div>
            <div className="text-[11px] text-cyan-400/90 font-medium -mt-1">Maritime Oil Spill Intelligence</div>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-8 text-xs font-medium text-slate-300">
          <Link to="/" className="text-cyan-400 font-semibold hover:text-cyan-300 transition-colors">Home</Link>
          <a href="#features" className="hover:text-cyan-400 transition-colors">Features</a>
          <a href="#methodology" className="hover:text-cyan-400 transition-colors">Methodology</a>
          <Link to="/mobile-preview" className="hover:text-cyan-400 transition-colors">SIH 2026 Rubric</Link>
          <Link to="/settings" className="hover:text-cyan-400 transition-colors">Contact</Link>
        </nav>

        <div className="flex items-center gap-3">
          <Link
            to="/login"
            className="px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/20 hover:shadow-cyan-400/40"
          >
            Login
          </Link>
        </div>
      </header>

      {/* Hero Section Matching Reference Image 1 Top Left */}
      <section className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 lg:px-12 pt-12 pb-16 text-center max-w-6xl mx-auto">
        {/* Brand Eyebrow */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-xs font-mono mb-6 backdrop-blur-sm">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
          <span>PROBLEM STATEMENT PS26143 • SIH 2026</span>
        </div>

        {/* Main Headline */}
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.15] mb-6 font-display max-w-4xl">
          “From Space to Sea, <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
            We Find the Truth.
          </span>”
        </h1>

        {/* Description */}
        <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed mb-8">
          AI-powered detection of oil spills from satellite imagery and AIS-based vessel attribution, for a cleaner ocean and a safer tomorrow.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
          <Link
            to="/login"
            className="flex items-center gap-2.5 px-7 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold text-sm tracking-wide transition-all shadow-xl shadow-cyan-500/25 cursor-pointer"
          >
            <span>GET STARTED</span>
            <ArrowRight className="w-4 h-4 text-slate-950" />
          </Link>

          <button
            onClick={() => setShowDemoModal(true)}
            className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 font-bold text-sm transition-all shadow-lg hover:border-cyan-400/50 cursor-pointer"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>WATCH DEMO</span>
          </button>
        </div>

        {/* Realistic Satellite / Ocean Visual with Tanker Wake Slick (Matching Reference Hero Image) */}
        <div className="w-full relative rounded-2xl overflow-hidden border border-cyan-500/30 bg-[#061120] shadow-2xl mb-16">
          <div className="w-full h-72 sm:h-96 relative overflow-hidden bg-[#071322]">
            {/* SVG Visual of Vessel Wake with Hydrocarbon Slick trailing on azure waters */}
            <svg className="w-full h-full" viewBox="0 0 1000 450" preserveAspectRatio="xMidYMid slice">
              <defs>
                <radialGradient id="heroOcean" cx="50%" cy="50%" r="70%">
                  <stop offset="0%" stopColor="#0a2a4a" />
                  <stop offset="50%" stopColor="#061930" />
                  <stop offset="100%" stopColor="#030b17" />
                </radialGradient>

                <linearGradient id="oilSheen" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#050a12" stopOpacity="0.95" />
                  <stop offset="40%" stopColor="#0f2638" stopOpacity="0.85" />
                  <stop offset="70%" stopColor="#0284c7" stopOpacity="0.5" />
                  <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.1" />
                </linearGradient>

                <filter id="waveNoise">
                  <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="3" result="noise" />
                  <feDisplacementMap in="SourceGraphic" in2="noise" scale="8" xChannelSelector="R" yChannelSelector="G" />
                </filter>
              </defs>

              {/* Ocean Canvas */}
              <rect width="1000" height="450" fill="url(#heroOcean)" />

              {/* Water Wave Swells */}
              <g stroke="rgba(56, 189, 248, 0.08)" strokeWidth="1.5" fill="none">
                <path d="M 0,120 Q 250,90 500,120 T 1000,120" />
                <path d="M 0,220 Q 250,190 500,220 T 1000,220" />
                <path d="M 0,320 Q 250,290 500,320 T 1000,320" />
              </g>

              {/* Dark Hydrocarbon Slick trailing from the ship */}
              <path
                d="M 680,180 C 580,175 480,210 380,240 C 260,275 160,310 0,330 L 0,420 C 180,410 320,360 460,320 C 560,290 640,240 690,190 Z"
                fill="url(#oilSheen)"
              />

              {/* Secondary spreading sheen with iridescent edges */}
              <path
                d="M 520,230 C 440,250 360,285 260,315 C 160,345 80,370 0,390 L 0,440 C 120,430 220,390 320,350 C 420,310 500,270 540,240 Z"
                fill="#030812"
                opacity="0.9"
              />

              {/* Vessel Wake Waves (White foaming spray) */}
              <path
                d="M 720,170 C 660,190 580,230 480,280 L 490,290 C 590,240 670,195 725,180 Z"
                fill="#bae6fd"
                opacity="0.6"
              />
              <path
                d="M 730,175 C 780,200 840,230 920,260 L 910,270 C 830,240 770,205 725,185 Z"
                fill="#bae6fd"
                opacity="0.4"
              />

              {/* Aframax Tanker Hull (Satellite Top-Down Angle) */}
              <g transform="translate(710, 160) rotate(-32)">
                {/* Ship shadow */}
                <ellipse cx="6" cy="12" rx="64" ry="18" fill="#000000" opacity="0.6" filter="blur(6px)" />
                {/* Ship hull */}
                <path
                  d="M -60,-12 L 40,-12 C 55,-12 65,-5 70,0 C 65,5 55,12 40,12 L -60,12 C -65,8 -65,-8 -60,-12 Z"
                  fill="#1e293b"
                  stroke="#475569"
                  strokeWidth="1.5"
                />
                {/* Tanker red deck */}
                <rect x="-45" y="-9" width="75" height="18" fill="#991b1b" rx="2" />
                {/* Bridge tower */}
                <rect x="-56" y="-7" width="10" height="14" fill="#f8fafc" rx="1" />
                {/* Pipeline line */}
                <line x1="-42" y1="0" x2="30" y2="0" stroke="#f1f5f9" strokeWidth="1" />
              </g>

              {/* Satellite Reticle HUD Overlays */}
              <g stroke="#06b6d4" strokeWidth="1" opacity="0.5">
                <circle cx="710" cy="160" r="45" fill="none" strokeDasharray="4 4" />
                <line x1="710" y1="100" x2="710" y2="220" />
                <line x1="650" y1="160" x2="770" y2="160" />
              </g>
            </svg>

            {/* Inset Label Badge */}
            <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-cyan-500/40 text-left">
              <div className="text-[10px] font-mono text-cyan-400 font-semibold uppercase">Real-Time SAR Ingestion</div>
              <div className="text-xs font-bold text-white">Arabian Sea Sector 04 • Sentinel-1 Pass</div>
            </div>

            <div className="absolute bottom-4 right-4 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-red-500/40 text-right">
              <div className="text-[10px] font-mono text-red-400 font-semibold uppercase">Continuous Slick Detected</div>
              <div className="text-xs font-bold text-white">Target Vessel: MV Ocean Star (Attribution 92%)</div>
            </div>
          </div>
        </div>

        {/* 4 Feature Columns Below (Matching Reference Image 1 Exact Layout) */}
        <div id="features" className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-left">
          {/* 1. Detect Oil Spills */}
          <div className="p-6 rounded-2xl bg-[#07111e]/90 border border-cyan-500/20 hover:border-cyan-500/50 transition-all group hover:-translate-y-1 shadow-lg">
            <div className="w-12 h-12 rounded-xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center text-cyan-300 mb-4 group-hover:scale-110 transition-transform">
              <Satellite className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-2 font-display">
              Detect Oil Spills <br />
              <span className="text-cyan-400 font-normal">from Satellite Imagery</span>
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Multi-spectral and SAR sensor analysis detects subtle hydrocarbon slicks across clouds and night.
            </p>
          </div>

          {/* 2. Correlate with AIS */}
          <div className="p-6 rounded-2xl bg-[#07111e]/90 border border-cyan-500/20 hover:border-cyan-500/50 transition-all group hover:-translate-y-1 shadow-lg">
            <div className="w-12 h-12 rounded-xl bg-blue-950/80 border border-blue-500/40 flex items-center justify-center text-blue-300 mb-4 group-hover:scale-110 transition-transform">
              <GitBranch className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-2 font-display">
              Correlate with AIS <br />
              <span className="text-blue-400 font-normal">Vessel Movement</span>
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Fuses automatic identification system trajectories, transponder gaps, and hydrodynamic drift models.
            </p>
          </div>

          {/* 3. Identify Responsible Vessel */}
          <div className="p-6 rounded-2xl bg-[#07111e]/90 border border-cyan-500/20 hover:border-cyan-500/50 transition-all group hover:-translate-y-1 shadow-lg">
            <div className="w-12 h-12 rounded-xl bg-red-950/80 border border-red-500/40 flex items-center justify-center text-red-300 mb-4 group-hover:scale-110 transition-transform">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-2 font-display">
              Identify Responsible <br />
              <span className="text-red-400 font-normal">Vessel</span>
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Multi-factor scoring algorithm isolates prime culprit ships with court-admissible audit reports.
            </p>
          </div>

          {/* 4. Support Sustainable Oceans */}
          <div className="p-6 rounded-2xl bg-[#07111e]/90 border border-cyan-500/20 hover:border-cyan-500/50 transition-all group hover:-translate-y-1 shadow-lg">
            <div className="w-12 h-12 rounded-xl bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-300 mb-4 group-hover:scale-110 transition-transform">
              <Globe2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white mb-2 font-display">
              Support Sustainable <br />
              <span className="text-emerald-400 font-normal">Oceans</span>
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Enables maritime coastguards and port state control to enforce UN SDG 14 life below water protections.
            </p>
          </div>
        </div>
      </section>

      {/* Demo Video Walkthrough Modal */}
      {showDemoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-3xl rounded-2xl bg-[#07111e] border border-cyan-500/40 p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <span className="font-bold text-white font-display text-base">VISION X • Operational System Demo</span>
              </div>
              <button
                onClick={() => setShowDemoModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="my-6 space-y-4 text-xs text-slate-300 leading-relaxed">
              <div className="p-4 rounded-xl bg-[#050b14] border border-cyan-500/20">
                <div className="font-bold text-cyan-300 text-sm mb-2">Connected Investigation Workflow:</div>
                <ol className="list-decimal pl-5 space-y-2">
                  <li><strong>Satellite SAR Ingestion:</strong> Multi-spectral Sentinel-1 C-Band radar detects surface roughness damping caused by crude oil slicks.</li>
                  <li><strong>AI Segmentation (MobileNetV3):</strong> Generates 96.7% confidence polygon covering 12.4 km² off the western Arabian Sea.</li>
                  <li><strong>AIS Telemetry Correlation:</strong> Correlates 27 candidate tracks within a ±6 hour window, highlighting a 40-minute intentional AIS transponder gap by <strong>MV Ocean Star</strong>.</li>
                  <li><strong>Vessel Attribution Dossier:</strong> Compiles comprehensive timeline, drift vector modeling, and generates exportable court-ready investigation report.</li>
                </ol>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowDemoModal(false)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setShowDemoModal(false);
                  navigate('/login');
                }}
                className="px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs"
              >
                Launch Prototype
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
