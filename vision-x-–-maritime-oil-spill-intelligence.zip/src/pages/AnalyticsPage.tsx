import React, { useState } from 'react';
import { 
  BarChart3, 
  PieChart, 
  TrendingUp, 
  TrendingDown, 
  Download, 
  Calendar, 
  Clock, 
  Ship, 
  Globe, 
  Activity, 
  ShieldCheck, 
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { mockDetectionsTrend } from '../data/mockData';

export const AnalyticsPage: React.FC = () => {
  const [dateRange, setDateRange] = useState('Last 7 Days');

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight font-display flex items-center gap-2.5">
            Reports & Analytics
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 text-xs font-mono font-normal border border-cyan-500/30">
              TRENDS & MODEL PERFORMANCE
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Historical spill occurrence analysis, model attribution accuracy, and regional maritime surveillance coverage.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto">
          {/* Date Filter Dropdown */}
          <div className="relative">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              aria-label="Select Date Range"
              className="appearance-none bg-[#091629] border border-cyan-500/40 rounded-xl px-4 py-2 pr-8 text-xs font-semibold text-slate-200 focus:outline-none focus:border-cyan-400 cursor-pointer font-mono"
            >
              <option>Last 24 Hours</option>
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
              <option>Last Quarter (Q3 2026)</option>
            </select>
            <Calendar className="w-3.5 h-3.5 text-cyan-400 absolute right-2.5 top-2.5 pointer-events-none" />
          </div>

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-xs font-bold transition-all shadow-md shadow-cyan-500/20 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* KPI Cards (Matches Reference Screenshot) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Total Spills Detected */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1 font-mono">
            <span>Total Spills Detected</span>
            <div className="w-7 h-7 rounded-lg bg-red-950/80 border border-red-500/40 flex items-center justify-center text-red-400">
              <Activity className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-3xl font-extrabold text-white font-display">12</span>
            <span className="text-xs font-mono text-emerald-400 flex items-center">
              <ArrowUpRight className="w-3 h-3" /> +33%
            </span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-1">vs previous period</div>
        </div>

        {/* 2. Avg Detection Time */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1 font-mono">
            <span>Avg Detection Time</span>
            <div className="w-7 h-7 rounded-lg bg-blue-950/80 border border-blue-500/40 flex items-center justify-center text-cyan-400">
              <Clock className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-3xl font-extrabold text-white font-display">42</span>
            <span className="text-xs font-mono text-slate-400 font-bold">min</span>
            <span className="text-xs font-mono text-emerald-400 flex items-center">
              <ArrowDownRight className="w-3 h-3" /> -58%
            </span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-1">from raw SAR pass</div>
        </div>

        {/* 3. Vessels Identified */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1 font-mono">
            <span>Vessels Identified</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Ship className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-3xl font-extrabold text-white font-display">9</span>
            <span className="text-xs font-mono text-emerald-400 flex items-center">
              <ArrowUpRight className="w-3 h-3" /> +50%
            </span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-1">75% attribution rate</div>
        </div>

        {/* 4. Area Covered */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1 font-mono">
            <span>Area Covered</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
              <Globe className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-3xl font-extrabold text-white font-display">48.6 M</span>
            <span className="text-xs font-mono text-slate-400 font-bold">km²</span>
            <span className="text-xs font-mono text-emerald-400 flex items-center">
              <ArrowUpRight className="w-3 h-3" /> +22%
            </span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-1">Cumulative SAR swath</div>
        </div>
      </div>

      {/* Two Main Charts (Matches Reference Screenshot) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Spill Detection Trend Bar Chart (7 Cols) */}
        <div className="lg:col-span-7 p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white font-display uppercase tracking-wider">
                  Spill Detection Trend
                </h3>
                <p className="text-[11px] text-slate-400 font-mono">28 Aug – 04 Sep 2026 Daily Count</p>
              </div>
              <span className="text-xs font-mono text-cyan-300 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/30">
                12 Incidents
              </span>
            </div>

            {/* Custom Interactive SVG Bar Chart */}
            <div className="h-64 w-full">
              <svg viewBox="0 0 500 240" className="w-full h-full overflow-visible">
                {/* Horizontal Guide Lines with Labels */}
                {[4, 3, 2, 1, 0].map((val, idx) => {
                  const y = 30 + idx * 45;
                  return (
                    <g key={val}>
                      <line x1="40" y1={y} x2="480" y2={y} stroke="#1e293b" strokeWidth="0.8" strokeDasharray="3 3" />
                      <text x="25" y={y + 4} fill="#64748b" fontSize="10" fontFamily="monospace" textAnchor="end">
                        {val}
                      </text>
                    </g>
                  );
                })}

                {/* Bars */}
                {mockDetectionsTrend.map((item, idx) => {
                  const barWidth = 38;
                  const x = 55 + idx * 56;
                  const maxVal = 4;
                  const barHeight = (item.count / maxVal) * 180;
                  const y = 210 - barHeight;

                  return (
                    <g key={item.date} className="group cursor-pointer">
                      {/* Hover effect background */}
                      <rect
                        x={x - 6}
                        y="20"
                        width={barWidth + 12}
                        height="195"
                        fill="rgba(6, 182, 212, 0.04)"
                        rx="6"
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                      />

                      {/* Bar body */}
                      <rect
                        x={x}
                        y={y}
                        width={barWidth}
                        height={Math.max(6, barHeight)}
                        rx="5"
                        fill={item.count >= 3 ? '#06b6d4' : item.count === 2 ? '#0284c7' : '#0369a1'}
                        className="transition-all group-hover:fill-cyan-300"
                        style={{
                          filter: item.count >= 3 ? 'drop-shadow(0 0 8px rgba(6,182,212,0.6))' : 'none',
                        }}
                      />

                      {/* Value label on top */}
                      <text
                        x={x + barWidth / 2}
                        y={y - 8}
                        textAnchor="middle"
                        fill="#f8fafc"
                        fontSize="11"
                        fontWeight="bold"
                        fontFamily="monospace"
                      >
                        {item.count}
                      </text>

                      {/* Date label at bottom */}
                      <text
                        x={x + barWidth / 2}
                        y="228"
                        textAnchor="middle"
                        fill="#94a3b8"
                        fontSize="10"
                        fontFamily="monospace"
                      >
                        {item.date.split(' ')[0]}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400 font-mono">
            <span>Peak detection: Friday 04 Sep (3 verified slicks)</span>
            <span className="text-cyan-400">Mean: 1.5 / day</span>
          </div>
        </div>

        {/* Right: Spill Type Distribution Donut Chart (5 Cols) */}
        <div className="lg:col-span-5 p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white font-display uppercase tracking-wider">
                  Spill Type Distribution
                </h3>
                <p className="text-[11px] text-slate-400 font-mono">By Surface Footprint Size</p>
              </div>
              <PieChart className="w-4 h-4 text-cyan-400" />
            </div>

            {/* Custom SVG Donut Chart matching reference */}
            <div className="flex flex-col items-center justify-center my-4">
              <div className="relative w-44 h-44">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 160 160">
                  {/* Background Circle */}
                  <circle cx="80" cy="80" r="58" stroke="#0a1c33" strokeWidth="22" fill="none" />

                  {/* Segment 1: Small (62%) - Cyan */}
                  {/* Circumference = 2 * PI * 58 = 364.42 */}
                  <circle
                    cx="80"
                    cy="80"
                    r="58"
                    stroke="#06b6d4"
                    strokeWidth="22"
                    strokeDasharray="225.9 364.4"
                    strokeDashoffset="0"
                    fill="none"
                  />

                  {/* Segment 2: Medium (25%) - Amber */}
                  <circle
                    cx="80"
                    cy="80"
                    r="58"
                    stroke="#f59e0b"
                    strokeWidth="22"
                    strokeDasharray="91.1 364.4"
                    strokeDashoffset="-225.9"
                    fill="none"
                  />

                  {/* Segment 3: Large (13%) - Red */}
                  <circle
                    cx="80"
                    cy="80"
                    r="58"
                    stroke="#ef4444"
                    strokeWidth="22"
                    strokeDasharray="47.4 364.4"
                    strokeDashoffset="-317"
                    fill="none"
                  />
                </svg>

                {/* Center text inside donut */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-2xl font-extrabold text-white font-display">12</span>
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                    Total Spills
                  </span>
                </div>
              </div>

              {/* Donut Legend matching reference screenshot */}
              <div className="w-full grid grid-cols-3 gap-2 text-center text-xs font-mono mt-4 pt-3 border-t border-slate-800">
                <div className="p-2 rounded bg-[#050e1a] border border-slate-800">
                  <div className="flex items-center justify-center gap-1.5 text-cyan-300 font-bold">
                    <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                    Small
                  </div>
                  <div className="text-lg font-bold text-white mt-0.5">62%</div>
                  <div className="text-[10px] text-slate-400">&lt; 5 km²</div>
                </div>

                <div className="p-2 rounded bg-[#050e1a] border border-slate-800">
                  <div className="flex items-center justify-center gap-1.5 text-amber-300 font-bold">
                    <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                    Medium
                  </div>
                  <div className="text-lg font-bold text-white mt-0.5">25%</div>
                  <div className="text-[10px] text-slate-400">5–10 km²</div>
                </div>

                <div className="p-2 rounded bg-[#050e1a] border border-slate-800">
                  <div className="flex items-center justify-center gap-1.5 text-red-300 font-bold">
                    <span className="w-2 h-2 rounded-full bg-red-400"></span>
                    Large
                  </div>
                  <div className="text-lg font-bold text-white mt-0.5">13%</div>
                  <div className="text-[10px] text-slate-400">&gt; 10 km²</div>
                </div>
              </div>
            </div>
          </div>

          <div className="text-[10px] text-slate-400 font-mono text-center">
            87% of all recorded incidents occurred along commercial tanker routes.
          </div>
        </div>
      </div>

      {/* Performance Metrics Row (Matches Reference Screenshot) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Detection Accuracy */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 mb-1">Detection Accuracy</div>
          <div className="text-2xl font-extrabold text-white font-display">94.3%</div>
          <div className="text-xs font-mono text-emerald-400 mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> +2.1% improvement
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">Benchmarked on SAR dataset</div>
        </div>

        {/* 2. Average Response Time */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 mb-1">Average Response Time</div>
          <div className="text-2xl font-extrabold text-white font-display">34 min</div>
          <div className="text-xs font-mono text-emerald-400 mt-1 flex items-center gap-1">
            <TrendingDown className="w-3 h-3" /> -18% faster
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">From alert to attribution</div>
        </div>

        {/* 3. Vessel Attribution Success */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 mb-1">Vessel Attribution Success</div>
          <div className="text-2xl font-extrabold text-white font-display">88.5%</div>
          <div className="text-xs font-mono text-emerald-400 mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> +4.2% improvement
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">High confidence isolation</div>
        </div>

        {/* 4. False Positive Rate */}
        <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
          <div className="text-xs font-semibold text-slate-400 mb-1">False Positive Rate</div>
          <div className="text-2xl font-extrabold text-white font-display">2.1%</div>
          <div className="text-xs font-mono text-emerald-400 mt-1 flex items-center gap-1">
            <TrendingDown className="w-3 h-3" /> -0.8% reduction
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">Algae bloom / calm sea filter</div>
        </div>
      </div>
    </div>
  );
};
