import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FileText, 
  Download, 
  Share2, 
  AlertTriangle, 
  CheckCircle2, 
  Calendar, 
  Clock, 
  Ship, 
  Satellite, 
  GitBranch, 
  ShieldCheck, 
  Printer, 
  ExternalLink,
  ChevronRight,
  Shield,
  FileCheck,
  Check,
  Award
} from 'lucide-react';
import { AttributionGauge } from '../components/visuals/AttributionGauge';
import { mockIncidents, mockCandidateVessels } from '../data/mockData';

export const InvestigationReportPage: React.FC = () => {
  const navigate = useNavigate();
  const incident = mockIncidents[0]; // VXN-2026-0001
  const vessel = mockCandidateVessels[0]; // MV Ocean Star
  const [activeTab, setActiveTab] = useState<'Overview' | 'Satellite Evidence' | 'AIS Evidence' | 'Vessel Analysis' | 'Timeline' | 'Audit Trail'>('Overview');
  const [copied, setCopied] = useState(false);

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header & Export/Share Actions matching reference screenshot */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight font-display flex items-center gap-2.5">
            Incident Investigation Report
            <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 text-xs font-mono border border-slate-700">
              OFFICIAL DOSSIER
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Forensic correlation between multi-spectral SAR satellite imagery and automatic identification system (AIS) telemetry.
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all border border-slate-700 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>EXPORT PDF</span>
          </button>

          <button
            onClick={handleShare}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-200 text-xs font-semibold transition-all cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'SHARE'}</span>
          </button>
        </div>
      </div>

      {/* Incident Header Stats Bar (Matches Reference Screenshot) */}
      <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg grid grid-cols-2 md:grid-cols-5 gap-4">
        <div>
          <div className="text-[10px] font-mono text-slate-400 uppercase">Incident ID</div>
          <div className="text-sm font-bold text-white font-mono mt-0.5">{incident.id}</div>
          <div className="text-[10px] text-cyan-400 font-mono">Spill Event #001</div>
        </div>

        <div>
          <div className="text-[10px] font-mono text-slate-400 uppercase">Severity</div>
          <div className="mt-0.5">
            <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 text-xs font-bold font-mono border border-red-500/40 inline-flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse"></span>
              High
            </span>
          </div>
        </div>

        <div>
          <div className="text-[10px] font-mono text-slate-400 uppercase">Detection Confidence</div>
          <div className="text-sm font-bold text-cyan-300 font-display mt-0.5">96.7%</div>
          <div className="text-[10px] text-slate-400 font-mono">MobileNetV3 SAR-Net</div>
        </div>

        <div>
          <div className="text-[10px] font-mono text-slate-400 uppercase">Detected At</div>
          <div className="text-xs font-bold text-slate-200 font-mono mt-0.5">04 Sep 2026 13:42 UTC</div>
          <div className="text-[10px] text-slate-400 font-mono">12.34°N, 68.75°E</div>
        </div>

        <div>
          <div className="text-[10px] font-mono text-slate-400 uppercase">Status</div>
          <div className="mt-0.5">
            <span className="px-2.5 py-0.5 rounded bg-amber-950/80 text-amber-300 text-xs font-semibold font-mono border border-amber-500/30">
              Under Investigation
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs matching reference */}
      <div className="flex items-center gap-1 border-b border-slate-800 text-xs font-medium overflow-x-auto pb-1">
        {(['Overview', 'Satellite Evidence', 'AIS Evidence', 'Vessel Analysis', 'Timeline', 'Audit Trail'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-t-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === tab
                ? 'bg-cyan-950/60 text-cyan-200 border-b-2 border-cyan-400 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Main Forensic Evidence Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: Satellite & AIS Evidence Cards (7 Cols) */}
        <div className="md:col-span-7 space-y-4">
          {/* Satellite Evidence Card */}
          <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-white font-display flex items-center gap-1.5 uppercase tracking-wider">
                <Satellite className="w-4 h-4 text-cyan-400" />
                Satellite Evidence
              </span>
              <span className="text-[10px] font-mono text-cyan-300">Sensor: Sentinel-1 SAR</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Original Image */}
              <div className="p-2 rounded-lg bg-[#050e1b] border border-slate-800">
                <div className="text-[10px] font-mono text-slate-400 mb-1">Original Image (SAR)</div>
                <div className="h-32 rounded bg-slate-900 overflow-hidden relative border border-slate-700 flex items-center justify-center">
                  <div className="w-16 h-12 bg-slate-800 rounded-full blur-xs" />
                  <span className="absolute bottom-1.5 left-2 text-[9px] font-mono text-cyan-300 bg-black/70 px-1.5 py-0.5 rounded">
                    C-BAND VV
                  </span>
                </div>
              </div>

              {/* Detection Overlay */}
              <div className="p-2 rounded-lg bg-[#050e1b] border border-slate-800">
                <div className="text-[10px] font-mono text-slate-400 mb-1">Detection Overlay (Mask)</div>
                <div className="h-32 rounded bg-slate-900 overflow-hidden relative border border-red-500/40 flex items-center justify-center">
                  <div className="w-16 h-12 bg-red-600/80 rounded-full blur-xs" />
                  <div className="w-8 h-6 bg-yellow-400/90 rounded-full blur-xs absolute" />
                  <span className="absolute bottom-1.5 right-2 text-[9px] font-mono text-red-300 bg-black/70 px-1.5 py-0.5 rounded">
                    12.4 km² SLICK
                  </span>
                </div>
              </div>
            </div>

            {/* Satellite Evidence Metadata */}
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs font-mono text-slate-300 bg-[#050e1a] p-3 rounded-lg border border-slate-800">
              <div>Coordinates: <span className="text-white font-bold">{incident.coordinates.display}</span></div>
              <div>Model Confidence: <span className="text-cyan-300 font-bold">{incident.confidence}%</span></div>
              <div>Detection Time: <span className="text-white">04 Sep 2026 12:30 UTC</span></div>
              <div>Image Source: <span className="text-slate-300">{incident.sensor}</span></div>
            </div>
          </div>

          {/* AIS Evidence Card */}
          <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-white font-display flex items-center gap-1.5 uppercase tracking-wider">
                <Ship className="w-4 h-4 text-cyan-400" />
                AIS Evidence
              </span>
              <span className="text-[10px] font-mono text-red-400">Rank #1 Suspect Target</span>
            </div>

            <div className="flex items-center gap-4 p-3 rounded-lg bg-[#050e1b] border border-slate-800">
              <div className="w-20 h-16 rounded bg-slate-900 overflow-hidden relative border border-slate-700 shrink-0 flex items-center justify-center">
                <Ship className="w-8 h-8 text-cyan-400" />
                <span className="absolute bottom-0.5 right-0.5 text-[8px] font-mono text-slate-300 bg-black/80 px-1 rounded">
                  LR
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  {vessel.name}
                  <span className="px-1.5 py-0.2 rounded bg-red-950 text-red-300 text-[9px] font-bold">
                    92% ATTRIBUTED
                  </span>
                </div>
                <div className="text-xs font-mono text-slate-400 mt-0.5">
                  IMO: {vessel.imo} • MMSI: {vessel.mmsi} • Flag: {vessel.flag}
                </div>
                <div className="text-[11px] text-cyan-300 font-mono mt-1">
                  Operator: {vessel.operator}
                </div>
              </div>
            </div>

            {/* AIS Match Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
              <div className="p-2 rounded bg-[#050e1a] border border-slate-800">
                <div className="text-[10px] text-slate-400">Distance from Spill</div>
                <div className="text-sm font-bold text-white mt-0.5">{vessel.distanceKm} km</div>
              </div>
              <div className="p-2 rounded bg-[#050e1a] border border-slate-800">
                <div className="text-[10px] text-slate-400">Time Overlap</div>
                <div className="text-sm font-bold text-cyan-300 mt-0.5">{vessel.timeMatchPct}%</div>
              </div>
              <div className="p-2 rounded bg-[#050e1a] border border-slate-800">
                <div className="text-[10px] text-slate-400">Track Match</div>
                <div className="text-sm font-bold text-blue-300 mt-0.5">{vessel.trackMatchPct}%</div>
              </div>
              <div className="p-2 rounded bg-[#050e1a] border border-slate-800">
                <div className="text-[10px] text-slate-400">AIS Signal Gap</div>
                <div className="text-sm font-bold text-red-400 mt-0.5">{vessel.aisGapMin} min</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Timeline & Attribution Analysis (5 Cols) */}
        <div className="md:col-span-5 space-y-4">
          {/* Vessel Timeline (Matches Reference Screenshot) */}
          <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-white font-display flex items-center gap-1.5 uppercase tracking-wider">
                <Clock className="w-4 h-4 text-cyan-400" />
                Vessel Chronological Timeline
              </span>
              <span className="text-[10px] font-mono text-slate-400">04 Sep 2026</span>
            </div>

            <div className="space-y-3 font-mono text-xs pl-2">
              <div className="flex items-start gap-3">
                <span className="text-cyan-300 font-bold shrink-0">11:45</span>
                <div>
                  <div className="font-semibold text-white">Vessel enters area</div>
                  <div className="text-[10px] text-slate-400">Entering Arabian corridor at 13.2 kts</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <span className="text-amber-300 font-bold shrink-0">12:35</span>
                <div>
                  <div className="font-semibold text-amber-200">Approaching spill zone</div>
                  <div className="text-[10px] text-slate-400">Course deflection observed (18° turn)</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <span className="text-red-400 font-bold shrink-0">13:10</span>
                <div>
                  <div className="font-semibold text-red-300">AIS signal lost (40 min)</div>
                  <div className="text-[10px] text-slate-400">Intentional transponder blackout period</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <span className="text-red-400 font-bold shrink-0">13:42</span>
                <div>
                  <div className="font-semibold text-red-200">Spill detected</div>
                  <div className="text-[10px] text-slate-400">Sentinel-1 records 12.4 km² slick</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <span className="text-emerald-400 font-bold shrink-0">14:25</span>
                <div>
                  <div className="font-semibold text-emerald-200">Vessel reappears</div>
                  <div className="text-[10px] text-slate-400">Accelerating to 13.9 kts down-drift</div>
                </div>
              </div>
            </div>
          </div>

          {/* Attribution Analysis Circular Meter */}
          <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg space-y-3 text-center flex flex-col items-center">
            <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider">
              Attribution Analysis
            </span>

            <AttributionGauge
              score={92}
              size={130}
              strokeWidth={10}
              label="Attribution Score"
              sublabel="High Match"
            />

            <div className="text-left w-full space-y-1.5 text-[11px] text-slate-300 border-t border-slate-800/80 pt-3">
              <div className="text-xs font-bold text-white mb-1">
                MV Ocean Star ranked #1 based on:
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Spatial proximity (2.1 km to slick origin)</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Temporal consistency (94% time window overlap)</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Trajectory match & drift pattern intersection</span>
              </div>
              <div className="flex items-center gap-1.5 text-red-400">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>AIS anomaly (40 min transponder blackout)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Supporting Evidence Strip + Incident Summary Statement (Matching Reference Bottom) */}
      <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl space-y-4">
        <div>
          <div className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider mb-2.5">
            Supporting Evidence Dossier
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* 1. Satellite Image */}
            <div className="p-2.5 rounded-xl bg-[#050e1b] border border-slate-800 text-center">
              <div className="h-20 rounded bg-slate-900 mb-1.5 flex items-center justify-center border border-slate-700">
                <Satellite className="w-7 h-7 text-cyan-400" />
              </div>
              <div className="text-xs font-semibold text-slate-200">Satellite Image</div>
              <div className="text-[10px] font-mono text-slate-400">Sentinel-1 SAR C-Band</div>
            </div>

            {/* 2. AIS Track Overlay */}
            <div className="p-2.5 rounded-xl bg-[#050e1b] border border-slate-800 text-center">
              <div className="h-20 rounded bg-slate-900 mb-1.5 flex items-center justify-center border border-slate-700">
                <GitBranch className="w-7 h-7 text-blue-400" />
              </div>
              <div className="text-xs font-semibold text-slate-200">AIS Track Overlay</div>
              <div className="text-[10px] font-mono text-slate-400">MarineTraffic Ingest</div>
            </div>

            {/* 3. Drift Simulation */}
            <div className="p-2.5 rounded-xl bg-[#050e1b] border border-slate-800 text-center">
              <div className="h-20 rounded bg-slate-900 mb-1.5 flex items-center justify-center border border-slate-700">
                <Clock className="w-7 h-7 text-amber-400" />
              </div>
              <div className="text-xs font-semibold text-slate-200">Drift Simulation</div>
              <div className="text-[10px] font-mono text-slate-400">NOAA HYCOM 1.4 kts</div>
            </div>

            {/* 4. Vessel Profile */}
            <div className="p-2.5 rounded-xl bg-[#050e1b] border border-slate-800 text-center">
              <div className="h-20 rounded bg-slate-900 mb-1.5 flex items-center justify-center border border-slate-700">
                <Ship className="w-7 h-7 text-emerald-400" />
              </div>
              <div className="text-xs font-semibold text-slate-200">Vessel Profile</div>
              <div className="text-[10px] font-mono text-slate-400">Aframax Crude Tanker</div>
            </div>
          </div>
        </div>

        {/* Incident Summary Card matching reference screenshot */}
        <div className="p-4 rounded-xl bg-[#050e1a] border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-xs font-bold text-white font-display uppercase tracking-wider flex items-center gap-1.5">
              <Award className="w-4 h-4 text-cyan-400" />
              Official Incident Summary
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
              The VISION X system detected an oil spill using satellite imagery and correlated AIS data to identify <strong className="text-white">MV Ocean Star</strong> as the most likely vessel responsible, with <strong className="text-cyan-300">92% attribution confidence</strong>. The dossier has been validated for regulatory submission.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => alert("Official verification stamp generated. Dossier hash: 0x9f4a2b...88c SHA256.")}
              className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-all shadow-md cursor-pointer"
            >
              Verify Digital Seal
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
