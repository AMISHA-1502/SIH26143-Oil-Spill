import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Smartphone, 
  CheckCircle2, 
  Sparkles, 
  ShieldCheck, 
  Award, 
  Layers, 
  ArrowRight, 
  AlertTriangle, 
  Ship, 
  Radio, 
  BarChart2, 
  Bell, 
  ExternalLink,
  ChevronRight,
  Maximize,
  Compass
} from 'lucide-react';
import { mockIncidents, mockCandidateVessels } from '../data/mockData';

export const MobilePreviewPage: React.FC = () => {
  const navigate = useNavigate();
  const [mobileTab, setMobileTab] = useState<'map' | 'alerts' | 'report'>('map');
  const incident = mockIncidents[0];
  const vessel = mockCandidateVessels[0];

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight font-display flex items-center gap-2.5">
            Responsive Mobile View & SIH Evaluation Rubric
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 text-xs font-mono font-normal border border-cyan-500/30">
              SIH 2026 • PS26143
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Optimized for coastal coast guard patrol vessels, field inspectors, port state control authorities, and tablets.
          </p>
        </div>
      </div>

      {/* Two-Column Grid: Left Phone Mockup + Right SIH Rubric Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Interactive Realistic Mobile Phone Mockup (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="text-xs font-mono text-cyan-400 mb-2 flex items-center gap-1.5">
            <Smartphone className="w-4 h-4" />
            <span>Interactive Mobile Simulator (Tap to Test)</span>
          </div>

          {/* Smartphone Frame */}
          <div className="w-[320px] sm:w-[350px] h-[660px] bg-[#02050d] rounded-[42px] p-3.5 border-4 border-slate-700 shadow-2xl shadow-cyan-950/40 relative flex flex-col justify-between overflow-hidden">
            {/* Speaker & Camera Notch */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-36 h-5 bg-slate-800 rounded-b-2xl z-30 flex items-center justify-center">
              <div className="w-10 h-1 bg-slate-600 rounded-full" />
              <div className="w-2.5 h-2.5 bg-slate-900 rounded-full ml-3 border border-slate-700" />
            </div>

            {/* Mobile Screen Inside */}
            <div className="w-full h-full bg-[#040a15] rounded-[30px] overflow-hidden flex flex-col pt-5 pb-2 text-slate-100">
              {/* Mobile App Bar */}
              <div className="px-3 py-2 border-b border-cyan-900/40 flex items-center justify-between bg-[#061120]">
                <div className="flex items-center gap-1.5">
                  <div className="w-5 h-5 rounded-md bg-cyan-500 flex items-center justify-center text-slate-950 font-bold text-[10px]">
                    VX
                  </div>
                  <span className="font-bold text-xs font-display text-white">VISION X</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-[9px] font-mono text-slate-400">14:32 UTC</span>
                </div>
              </div>

              {/* Mobile Content (Scrollable) */}
              <div className="flex-1 overflow-y-auto p-3 space-y-3">
                {/* 4 Mini KPI Chips */}
                <div className="grid grid-cols-4 gap-1.5 text-center">
                  <div className="p-1 rounded bg-[#091526] border border-red-500/30">
                    <div className="text-[8px] text-slate-400 font-mono">Spills</div>
                    <div className="text-xs font-bold text-red-400">3</div>
                  </div>
                  <div className="p-1 rounded bg-[#091526] border border-blue-500/30">
                    <div className="text-[8px] text-slate-400 font-mono">Vessels</div>
                    <div className="text-xs font-bold text-cyan-300">27</div>
                  </div>
                  <div className="p-1 rounded bg-[#091526] border border-emerald-500/30">
                    <div className="text-[8px] text-slate-400 font-mono">Area</div>
                    <div className="text-xs font-bold text-white">12.4M</div>
                  </div>
                  <div className="p-1 rounded bg-[#091526] border border-cyan-500/30">
                    <div className="text-[8px] text-slate-400 font-mono">Conf</div>
                    <div className="text-xs font-bold text-cyan-300">94%</div>
                  </div>
                </div>

                {mobileTab === 'map' && (
                  <>
                    {/* Mini SVG Radar Map */}
                    <div className="h-44 rounded-xl bg-[#030914] border border-cyan-500/30 relative overflow-hidden">
                      <svg viewBox="0 0 300 200" className="w-full h-full">
                        <circle cx="150" cy="100" r="40" stroke="#06b6d4" strokeWidth="0.5" strokeOpacity="0.3" fill="none" />
                        <circle cx="150" cy="100" r="80" stroke="#06b6d4" strokeWidth="0.5" strokeOpacity="0.2" fill="none" />
                        {/* Spill */}
                        <ellipse cx="140" cy="95" rx="26" ry="16" fill="#ef4444" opacity="0.8" />
                        {/* Target ship */}
                        <circle cx="180" cy="120" r="4" fill="#38bdf8" />
                        <line x1="120" y1="70" x2="180" y2="120" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="2 2" />
                      </svg>
                      <div className="absolute top-1.5 left-1.5 text-[8px] font-mono text-cyan-300 bg-black/60 px-1 rounded">
                        Sector 4 • Spill #001
                      </div>
                    </div>

                    {/* Alert Card */}
                    <div className="p-2.5 rounded-xl bg-[#081527] border border-red-500/40 space-y-1 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">Incident #001</span>
                        <span className="text-[9px] font-bold text-red-300 bg-red-950 px-1.5 py-0.2 rounded">
                          HIGH
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-300 font-mono">12.4 km² • Conf: 96.7%</div>
                      <button
                        onClick={() => navigate('/investigation-report')}
                        className="w-full mt-1 py-1 rounded bg-cyan-600 text-slate-950 font-bold text-[10px] flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <span>Inspect Dossier</span>
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </>
                )}

                {mobileTab === 'alerts' && (
                  <div className="space-y-2 text-xs">
                    <div className="p-2 rounded-lg bg-red-950/40 border border-red-500/40">
                      <div className="font-bold text-red-300 text-[11px]">High Severity Spill #001</div>
                      <div className="text-[9px] text-slate-300 mt-0.5">12.4 km² detected off Arabian coast</div>
                    </div>
                    <div className="p-2 rounded-lg bg-amber-950/40 border border-amber-500/40">
                      <div className="font-bold text-amber-300 text-[11px]">MV Ocean Star Correlated</div>
                      <div className="text-[9px] text-slate-300 mt-0.5">92% score with 40 min AIS gap</div>
                    </div>
                  </div>
                )}

                {mobileTab === 'report' && (
                  <div className="p-2.5 rounded-xl bg-[#081527] border border-cyan-500/30 text-xs space-y-2">
                    <div className="font-bold text-white text-[11px]">Dossier VXN-2026-0001</div>
                    <div className="text-[10px] text-slate-300 font-mono">Culprit: MV Ocean Star (Liberia)</div>
                    <div className="text-[10px] text-emerald-400 font-bold font-mono">Attribution: 92%</div>
                    <button
                      onClick={() => navigate('/investigation-report')}
                      className="w-full py-1 rounded bg-cyan-600 text-slate-950 font-bold text-[10px]"
                    >
                      Open Full Screen
                    </button>
                  </div>
                )}
              </div>

              {/* Mobile Bottom Navigation Bar matching reference screenshot */}
              <div className="px-2 py-1.5 border-t border-slate-800 bg-[#06101f] grid grid-cols-3 text-center text-[10px]">
                <button
                  onClick={() => setMobileTab('map')}
                  className={`py-1 rounded flex flex-col items-center ${mobileTab === 'map' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>Map</span>
                </button>
                <button
                  onClick={() => setMobileTab('alerts')}
                  className={`py-1 rounded flex flex-col items-center ${mobileTab === 'alerts' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
                >
                  <Bell className="w-3.5 h-3.5" />
                  <span>Alerts</span>
                </button>
                <button
                  onClick={() => setMobileTab('report')}
                  className={`py-1 rounded flex flex-col items-center ${mobileTab === 'report' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Report</span>
                </button>
              </div>

              {/* Home indicator bar */}
              <div className="w-24 h-1 bg-slate-600 rounded-full mx-auto mt-1" />
            </div>
          </div>
        </div>

        {/* Right: "Why This UI Works (SIH Rubric Alignment)" Matching Reference Image 2 Bottom Right */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-6 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white font-display">
                  Why This UI Works (SIH Rubric Alignment)
                </h2>
                <p className="text-xs text-slate-400">
                  Direct mapping of VISION X interface architecture to official Smart India Hackathon evaluation criteria.
                </p>
              </div>
            </div>

            {/* 5 Points Matching Reference Screenshot Exactly */}
            <div className="space-y-3.5 text-xs text-slate-300">
              {/* 1. Real-time Monitoring */}
              <div className="p-3.5 rounded-xl bg-[#050e1b] border border-slate-800/80 hover:border-cyan-500/30 transition-colors">
                <div className="font-bold text-white font-display text-sm flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-mono">1</span>
                  Real-time Monitoring
                </div>
                <p className="text-slate-300 mt-1 pl-7 leading-relaxed">
                  Immediate visibility of detected spills and vessel positions via integrated dashboard. Interactive Nautical Map displays live vessel tracks, drift envelopes, and spill polygons in unified situational awareness.
                </p>
              </div>

              {/* 2. AI-Powered Analysis */}
              <div className="p-3.5 rounded-xl bg-[#050e1b] border border-slate-800/80 hover:border-cyan-500/30 transition-colors">
                <div className="font-bold text-white font-display text-sm flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-mono">2</span>
                  AI-Powered Analysis
                </div>
                <p className="text-slate-300 mt-1 pl-7 leading-relaxed">
                  Clear presentation of satellite detection confidence (96.7%) and vessel attribution scores (92%). Side-by-side SAR Speckle Noise vs. AI Segmentation Mask demonstrates machine learning validity.
                </p>
              </div>

              {/* 3. Actionable Intelligence */}
              <div className="p-3.5 rounded-xl bg-[#050e1b] border border-slate-800/80 hover:border-cyan-500/30 transition-colors">
                <div className="font-bold text-white font-display text-sm flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-mono">3</span>
                  Actionable Intelligence
                </div>
                <p className="text-slate-300 mt-1 pl-7 leading-relaxed">
                  Step-by-step investigation workflow from detection to attribution report. Clear chronological timeline highlights 40-minute intentional AIS transponder blackouts for coast guard prosecution.
                </p>
              </div>

              {/* 4. User-Friendly & Intuitive */}
              <div className="p-3.5 rounded-xl bg-[#050e1b] border border-slate-800/80 hover:border-cyan-500/30 transition-colors">
                <div className="font-bold text-white font-display text-sm flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-mono">4</span>
                  User-Friendly & Intuitive
                </div>
                <p className="text-slate-300 mt-1 pl-7 leading-relaxed">
                  Clean dark-theme interface with high-contrast data visualization, cyan radar accents, responsive navigation, and consistent maritime typography.
                </p>
              </div>

              {/* 5. Scalable & Practical */}
              <div className="p-3.5 rounded-xl bg-[#050e1b] border border-slate-800/80 hover:border-cyan-500/30 transition-colors">
                <div className="font-bold text-white font-display text-sm flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-mono">5</span>
                  Scalable & Practical
                </div>
                <p className="text-slate-300 mt-1 pl-7 leading-relaxed">
                  Modular layout supports additional data layers (Sentinel-1, TerraSAR-X, NOAA HYCOM), vessel types (Crude Tankers, Cargo, Bunkering), and exportable PDF audit trails for maritime tribunals.
                </p>
              </div>
            </div>

            {/* Quick Action Navigation */}
            <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs font-mono text-slate-400">
                Project: <span className="text-white font-bold">VISION X</span> • PS: <span className="text-cyan-400 font-bold">PS26143</span>
              </div>
              <button
                onClick={() => navigate('/dashboard')}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-all shadow-md cursor-pointer"
              >
                <span>Return to Command Center</span>
                <ArrowRight className="w-4 h-4 text-slate-950" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
