import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Scan, 
  Upload, 
  History, 
  Layers, 
  Cpu, 
  MapPin, 
  Clock, 
  Maximize2, 
  ChevronRight, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight,
  Download,
  Share2,
  FileCheck,
  AlertOctagon
} from 'lucide-react';
import { SARVisualizer } from '../components/visuals/SARVisualizer';
import { mockIncidents } from '../data/mockData';
import { SpillIncident } from '../types';

export const SatelliteAnalysisPage: React.FC = () => {
  const navigate = useNavigate();
  const [selectedIncident, setSelectedIncident] = useState<SpillIncident>(mockIncidents[0]);
  const [activeWorkflowStep, setActiveWorkflowStep] = useState(2); // 1: Upload, 2: Run Detection, 3: Review, 4: Correlate
  const [detectionComplete, setDetectionComplete] = useState(true);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight font-display flex items-center gap-2.5">
            Satellite Analysis
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 text-xs font-mono font-normal border border-cyan-500/30">
              AI DETECTION WORKSPACE
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Detect oil spills from multi-spectral satellite imagery and SAR backscatter roughness analysis.
          </p>
        </div>

        {/* Action button to proceed */}
        <button
          onClick={() => navigate('/ais-correlation')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/20 cursor-pointer self-start sm:self-auto"
        >
          <span>Correlate with AIS</span>
          <ArrowRight className="w-4 h-4 text-slate-950" />
        </button>
      </div>

      {/* Stepper Workflow (Matching Reference Screenshot Top Bar) */}
      <div className="p-3.5 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-md">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {[
            { num: 1, title: 'Upload & Preprocess', desc: 'Sentinel-1 C-Band SAR' },
            { num: 2, title: 'Run Detection', desc: 'MobileNetV3 Inference' },
            { num: 3, title: 'Review Results', desc: 'Mask & Spatial Confidence' },
            { num: 4, title: 'Correlate with AIS', desc: 'Vessel Trajectory Match' },
          ].map((step) => {
            const isCompleted = step.num < activeWorkflowStep || (step.num === 2 && detectionComplete);
            const isCurrent = step.num === activeWorkflowStep;

            return (
              <div
                key={step.num}
                onClick={() => {
                  if (step.num === 4) navigate('/ais-correlation');
                  else setActiveWorkflowStep(step.num);
                }}
                className={`flex items-center gap-3 p-2.5 rounded-lg border transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-cyan-950/60 border-cyan-500/60 text-cyan-200'
                    : isCompleted
                    ? 'bg-slate-900/60 border-slate-700/60 text-slate-300'
                    : 'bg-slate-950/40 border-slate-800 text-slate-500'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                    isCurrent
                      ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-400'
                      : isCompleted
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : step.num}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold truncate">{step.title}</div>
                  <div className="text-[10px] text-slate-400 font-mono truncate">{step.desc}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Latest Detections Drawer (3 Cols) */}
        <div className="lg:col-span-3 space-y-4">
          <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider">
                Latest Detections
              </span>
              <div className="flex gap-1.5">
                <button
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
                  title="Historical Archives"
                >
                  <History className="w-3.5 h-3.5" />
                </button>
                <button
                  className="p-1.5 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 text-xs"
                  title="Upload Custom Image"
                >
                  <Upload className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* List of Incidents matching reference */}
            <div className="space-y-2.5 mt-3">
              {mockIncidents.map((incident, idx) => {
                const isSelected = selectedIncident.id === incident.id;
                return (
                  <div
                    key={incident.id}
                    onClick={() => setSelectedIncident(incident)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-950/40 border-cyan-500/60 shadow-md shadow-cyan-500/10'
                        : 'bg-[#050e1b] border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-bold text-white font-display flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${idx === 0 ? 'bg-red-400 animate-pulse' : 'bg-amber-400'}`}></span>
                        {incident.code}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        {idx === 0 ? '2h ago' : idx === 1 ? '7h ago' : '15h ago'}
                      </span>
                    </div>

                    {/* Coordinates & stats matching reference */}
                    <div className="text-[11px] font-mono text-slate-300 space-y-0.5">
                      <div>Lat: {incident.coordinates.lat}°N, Lon: {incident.coordinates.lng}°E</div>
                      <div>Area: <strong className="text-white">{incident.areaKm2} km²</strong></div>
                      <div>Confidence: <strong className="text-cyan-300">{incident.confidence}%</strong></div>
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                      <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                        incident.severity === 'High' ? 'bg-red-950 text-red-300' : 'bg-amber-950 text-amber-300'
                      }`}>
                        {incident.severity} Risk
                      </span>
                      <span className="text-[10px] text-cyan-400 hover:underline flex items-center gap-1">
                        Inspect
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Top Detected Area Thumbnail matching Reference Screenshot bottom right */}
          <div className="p-4 rounded-xl bg-[#081527] border border-cyan-500/30 shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-300 font-display">Detected Areas (Top 1)</span>
              <span className="text-[10px] font-mono text-red-400 font-bold">12.4 km²</span>
            </div>
            {/* Thumbnail */}
            <div className="h-28 rounded-lg bg-[#040b15] border border-red-500/40 relative overflow-hidden flex items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-red-600/70 blur-xs" />
              <div className="w-6 h-6 rounded-full bg-amber-400/90 blur-xs absolute" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_40%,rgba(4,11,21,0.8)_100%)]" />
              <div className="absolute bottom-1.5 left-2 text-[10px] font-mono text-cyan-300 bg-black/60 px-1.5 py-0.5 rounded">
                Conf: 96.7%
              </div>
            </div>
            <button
              onClick={() => navigate('/ais-correlation')}
              className="mt-3 w-full py-1.5 rounded-lg bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            >
              <span>View Mask & Correlate</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Center & Right: SAR Visualizer + Detection Details (9 Cols) */}
        <div className="lg:col-span-9 space-y-6">
          {/* Main Comparison Area */}
          <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white font-display">
                  Spill #001 — Satellite View
                </span>
                <span className="text-xs font-mono text-slate-400">| Arabian Sea Off-Coast Sector</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => alert("Downloading geotiff SAR segmentation mask bundle...")}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-medium cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Report</span>
                </button>
              </div>
            </div>

            {/* Interactive SAR Visualizer */}
            <SARVisualizer
              onRunComplete={() => setDetectionComplete(true)}
            />
          </div>

          {/* Detection Details Cards Grid (Matches Reference Screenshot) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-3 rounded-xl bg-[#081527] border border-cyan-500/20">
              <div className="text-[10px] text-slate-400 font-mono uppercase">Confidence</div>
              <div className="text-lg font-bold text-cyan-300 font-display">96.7%</div>
              <div className="text-[10px] text-emerald-400 font-mono">High Precision</div>
            </div>

            <div className="p-3 rounded-xl bg-[#081527] border border-cyan-500/20">
              <div className="text-[10px] text-slate-400 font-mono uppercase">Estimated Area</div>
              <div className="text-lg font-bold text-white font-display">12.4 km²</div>
              <div className="text-[10px] text-red-400 font-mono">Major Slick</div>
            </div>

            <div className="p-3 rounded-xl bg-[#081527] border border-cyan-500/20">
              <div className="text-[10px] text-slate-400 font-mono uppercase">Coordinates</div>
              <div className="text-xs font-bold text-white font-mono mt-1">12.34°N, 68.75°E</div>
              <div className="text-[10px] text-slate-400 font-mono">Arabian Basin</div>
            </div>

            <div className="p-3 rounded-xl bg-[#081527] border border-cyan-500/20">
              <div className="text-[10px] text-slate-400 font-mono uppercase">Detection Time</div>
              <div className="text-xs font-bold text-white font-mono mt-1">04 Sep 12:30</div>
              <div className="text-[10px] text-slate-400 font-mono">UTC Timestamp</div>
            </div>

            <div className="p-3 rounded-xl bg-[#081527] border border-cyan-500/20">
              <div className="text-[10px] text-slate-400 font-mono uppercase">Model Architecture</div>
              <div className="text-xs font-bold text-cyan-300 font-mono mt-1">MobileNetV3</div>
              <div className="text-[10px] text-slate-400 font-mono">Custom Maritime-Seg</div>
            </div>

            <div className="p-3 rounded-xl bg-[#081527] border border-cyan-500/20">
              <div className="text-[10px] text-slate-400 font-mono uppercase">Inference State</div>
              <div className="text-xs font-bold text-emerald-400 font-mono mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Complete
              </div>
              <div className="text-[10px] text-slate-400 font-mono">2.8s total time</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
