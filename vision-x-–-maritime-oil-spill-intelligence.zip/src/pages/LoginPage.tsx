import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, Mail, ArrowRight, Shield, CheckCircle2, Sparkles, AlertCircle } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('analyst@visionx.ai');
  const [password, setPassword] = useState('visionx123');
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      navigate('/dashboard');
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#040914] text-slate-100 flex items-center justify-center p-4 sm:p-6 relative overflow-hidden">
      {/* Background Graphic Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-[#061426] via-[#040b15] to-[#02050b]" />
        <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-cyan-600/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/10 blur-[140px] rounded-full" />
      </div>

      {/* Two-Column Card matching Reference Screenshot */}
      <div className="relative z-10 w-full max-w-4xl grid grid-cols-1 md:grid-cols-12 rounded-3xl overflow-hidden border border-cyan-500/30 bg-[#07111e]/90 shadow-2xl backdrop-blur-xl">
        {/* Left Side: Login Form (7 Cols) */}
        <div className="p-8 sm:p-10 md:col-span-7 flex flex-col justify-between">
          <div>
            {/* Logo */}
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center p-2 shadow-lg shadow-cyan-500/20">
                <svg viewBox="0 0 24 24" className="w-full h-full text-slate-950 stroke-current stroke-2 fill-none">
                  <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                  <circle cx="12" cy="12" r="3.5" className="fill-cyan-100" />
                </svg>
              </div>
              <div>
                <div className="text-xl font-black text-white tracking-wider font-display">VISION X</div>
                <div className="text-xs text-cyan-400 font-medium -mt-1">Maritime Oil Spill Intelligence</div>
              </div>
            </div>

            {/* Header */}
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-white font-display">Welcome Back</h2>
              <p className="text-xs text-slate-400 mt-1">
                Sign in to your account to access live satellite feeds & AIS correlation engine.
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 font-mono">
                  Email ID
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="analyst@visionx.ai"
                    className="w-full bg-[#091629] border border-slate-700/80 rounded-xl pl-10 pr-3 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 font-mono transition-colors"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-300 font-mono">
                    Password
                  </label>
                  <a href="#forgot" className="text-xs text-cyan-400 hover:underline">
                    Forgot password?
                  </a>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-[#091629] border border-slate-700/80 rounded-xl pl-10 pr-3 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 font-mono transition-colors"
                  />
                </div>
              </div>

              {/* Remember Me */}
              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300 select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded accent-cyan-500 w-4 h-4 cursor-pointer"
                  />
                  <span>Remember me</span>
                </label>
                <span className="text-[11px] font-mono text-cyan-400/80">Default Demo Credentials Pre-filled</span>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs tracking-wider transition-all shadow-lg shadow-cyan-500/20 disabled:opacity-50 cursor-pointer mt-2"
              >
                {isLoading ? (
                  <span>AUTHENTICATING TELEMETRY...</span>
                ) : (
                  <>
                    <span>SIGN IN</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Quick-Fill Demo Helpers */}
            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Demo Profiles:</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setEmail('analyst@visionx.ai');
                    setPassword('visionx123');
                  }}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 font-mono text-[10px]"
                >
                  Analyst
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEmail('amisha@teamvisionx.in');
                    setPassword('visionx123');
                  }}
                  className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 font-mono text-[10px]"
                >
                  Amisha (Lead)
                </button>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center text-xs text-slate-400">
            Don't have an account?{' '}
            <Link to="/settings" className="text-cyan-400 font-medium hover:underline">
              Contact Admin
            </Link>
          </div>
        </div>

        {/* Right Side: Ocean Quote & Visual (5 Cols) */}
        <div className="hidden md:flex md:col-span-5 relative bg-gradient-to-b from-[#0a1e36] to-[#040e1b] p-8 flex-col justify-between border-l border-cyan-500/20 overflow-hidden">
          {/* Subtle wave ripple effect */}
          <div className="absolute inset-0 opacity-20 pointer-events-none">
            <svg className="w-full h-full" viewBox="0 0 400 600">
              <path d="M -50,100 Q 150,50 350,150 T 450,300" fill="none" stroke="#38bdf8" strokeWidth="2" />
              <path d="M -50,250 Q 100,200 250,320 T 450,450" fill="none" stroke="#38bdf8" strokeWidth="1.5" />
              <path d="M -50,400 Q 200,350 400,480" fill="none" stroke="#06b6d4" strokeWidth="2" />
            </svg>
          </div>

          <div className="relative z-10 flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-300/80 bg-cyan-950/60 px-2.5 py-1 rounded border border-cyan-500/30">
              SECURE SATELLITE HUB
            </span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          </div>

          {/* Center Quote matching reference screenshot */}
          <div className="relative z-10 my-auto py-8">
            <div className="text-cyan-400 text-4xl font-serif mb-2 leading-none">“</div>
            <blockquote className="text-lg font-bold text-white leading-relaxed font-display">
              Cleaner oceans aren't just a goal, <br />
              <span className="text-cyan-300">they're a responsibility.</span>”
            </blockquote>
            <div className="mt-4 flex items-center gap-2 text-xs text-slate-400">
              <div className="w-6 h-0.5 bg-cyan-500" />
              <span>Team VISION X • SIH 2026</span>
            </div>
          </div>

          <div className="relative z-10 p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 font-mono">
            <div className="flex items-center gap-1.5 text-cyan-300 font-semibold mb-1">
              <Shield className="w-3.5 h-3.5" />
              <span>ISO/IEC 27001 Maritime Security</span>
            </div>
            Direct encrypted link to Sentinel-1 Synthetic Aperture Radar (SAR) Ground Stations.
          </div>
        </div>
      </div>
    </div>
  );
};
