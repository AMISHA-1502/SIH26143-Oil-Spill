import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Bell, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Filter, 
  Check, 
  Trash2, 
  ExternalLink,
  ChevronRight,
  Ship,
  Satellite,
  ShieldAlert,
  Radio
} from 'lucide-react';
import { mockAlerts } from '../data/mockData';
import { AlertItem } from '../types';

export const AlertsPage: React.FC = () => {
  const navigate = useNavigate();
  const [alerts, setAlerts] = useState<AlertItem[]>(mockAlerts);
  const [activeFilter, setActiveFilter] = useState<'all' | 'High' | 'Medium' | 'Low'>('all');

  const highCount = alerts.filter(a => a.severity === 'High').length;
  const mediumCount = alerts.filter(a => a.severity === 'Medium').length;
  const lowCount = alerts.filter(a => a.severity === 'Low').length;

  const filteredAlerts = alerts.filter(a => {
    if (activeFilter === 'all') return true;
    return a.severity === activeFilter;
  });

  const markAllRead = () => {
    setAlerts(prev => prev.map(a => ({ ...a, unread: false })));
  };

  const handleAction = (alert: AlertItem) => {
    if (alert.severity === 'High' && alert.title.includes('MV Ocean Star')) {
      navigate('/vessel-attribution');
    } else if (alert.severity === 'High') {
      navigate('/investigation-report');
    } else if (alert.title.includes('AIS')) {
      navigate('/ais-correlation');
    } else {
      navigate('/satellite-analysis');
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header matching reference */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight font-display flex items-center gap-2.5">
            Alerts & Notifications
            <span className="px-2.5 py-0.5 rounded-full bg-red-950 text-red-300 text-xs font-mono font-normal border border-red-500/40">
              {alerts.filter(a => a.unread).length} UNREAD
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time automated alerts for detected oil spills, satellite triggers, and high-risk vessel attribution flags.
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <button
            onClick={markAllRead}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-all border border-slate-700 cursor-pointer"
          >
            <Check className="w-3.5 h-3.5 text-cyan-400" />
            <span>Mark All as Read</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs matching reference screenshot: All (5), High (2), Medium (2), Low (1) */}
      <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-xs font-medium">
        <button
          onClick={() => setActiveFilter('all')}
          className={`px-3.5 py-1.5 rounded-lg transition-all cursor-pointer ${
            activeFilter === 'all'
              ? 'bg-cyan-600 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
          }`}
        >
          All ({alerts.length})
        </button>

        <button
          onClick={() => setActiveFilter('High')}
          className={`px-3.5 py-1.5 rounded-lg transition-all cursor-pointer ${
            activeFilter === 'High'
              ? 'bg-red-600 text-white font-bold shadow-md shadow-red-500/20'
              : 'bg-slate-900 text-red-400 hover:bg-slate-800'
          }`}
        >
          High ({highCount})
        </button>

        <button
          onClick={() => setActiveFilter('Medium')}
          className={`px-3.5 py-1.5 rounded-lg transition-all cursor-pointer ${
            activeFilter === 'Medium'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-900 text-amber-400 hover:bg-slate-800'
          }`}
        >
          Medium ({mediumCount})
        </button>

        <button
          onClick={() => setActiveFilter('Low')}
          className={`px-3.5 py-1.5 rounded-lg transition-all cursor-pointer ${
            activeFilter === 'Low'
              ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-500/20'
              : 'bg-slate-900 text-blue-400 hover:bg-slate-800'
          }`}
        >
          Low ({lowCount})
        </button>
      </div>

      {/* Alerts List matching reference screenshot */}
      <div className="space-y-3">
        {filteredAlerts.map((alert) => (
          <div
            key={alert.id}
            className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
              alert.unread
                ? 'bg-[#081527] border-cyan-500/40 shadow-lg'
                : 'bg-[#06101f]/70 border-slate-800/80 text-slate-400'
            }`}
          >
            {/* Left: Icon & Description */}
            <div className="flex items-start gap-3.5">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border mt-0.5 ${
                  alert.severity === 'High'
                    ? 'bg-red-950/80 border-red-500/50 text-red-400'
                    : alert.severity === 'Medium'
                    ? 'bg-amber-950/80 border-amber-500/50 text-amber-400'
                    : 'bg-blue-950/80 border-blue-500/50 text-blue-400'
                }`}
              >
                {alert.type === 'vessel_attribution' ? (
                  <Ship className="w-4 h-4" />
                ) : alert.type === 'ais_anomaly' ? (
                  <Radio className="w-4 h-4" />
                ) : (
                  <AlertTriangle className="w-4 h-4" />
                )}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase ${
                      alert.severity === 'High'
                        ? 'bg-red-950 text-red-300 border border-red-500/40'
                        : alert.severity === 'Medium'
                        ? 'bg-amber-950 text-amber-300 border border-amber-500/40'
                        : 'bg-blue-950 text-blue-300 border border-blue-500/40'
                    }`}
                  >
                    {alert.severity}
                  </span>
                  <span className="text-sm font-bold text-white font-display">
                    {alert.title}
                  </span>
                  {alert.unread && (
                    <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                  )}
                </div>

                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {alert.description}
                </p>

                <div className="text-[11px] font-mono text-slate-400 mt-1.5 flex items-center gap-2">
                  <Clock className="w-3 h-3 text-slate-500" />
                  <span>{alert.timestamp}</span>
                </div>
              </div>
            </div>

            {/* Right: Action Button matching reference */}
            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
              <button
                onClick={() => handleAction(alert)}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                  alert.severity === 'High'
                    ? 'bg-cyan-600 hover:bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/20'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                }`}
              >
                <span>{alert.actionLabel}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
