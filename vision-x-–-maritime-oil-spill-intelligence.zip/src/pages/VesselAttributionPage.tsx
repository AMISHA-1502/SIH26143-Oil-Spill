import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ShieldAlert, 
  Download, 
  Share2, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  Ship, 
  Compass, 
  FileText, 
  ExternalLink,
  ChevronRight,
  AlertOctagon,
  Anchor,
  Layers,
  ArrowRight,
  Copy,
  Check
} from 'lucide-react';
import { AttributionGauge } from '../components/visuals/AttributionGauge';
import { VesselGraphic } from '../components/visuals/VesselGraphic';
import { mockCandidateVessels, mockOceanStarTimeline } from '../data/mockData';

export const VesselAttributionPage: React.FC = () => {
  const navigate = useNavigate();
  const vessel = mockCandidateVessels[0]; // MV Ocean Star
  const [copied, setCopied] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'evidence' | 'timeline' | 'spec'>('evidence');

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header with Export / Share buttons matching reference screenshot */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-1">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight font-display flex items-center gap-2.5">
            Vessel Attribution Report
            <span className="px-2.5 py-0.5 rounded-full bg-red-950 text-red-300 text-xs font-mono font-normal border border-red-500/40">
              HIGH CONFIDENCE MATCH
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Detailed forensic analysis, multi-sensor evidence chain, and court-admissible maritime attribution dossier.
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all border border-slate-700 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export PDF</span>
          </button>

          <button
            onClick={handleShare}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-200 text-xs font-semibold transition-all cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'Link Copied!' : 'Share'}</span>
          </button>

          <button
            onClick={() => navigate('/investigation-report')}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/20 cursor-pointer"
          >
            <span>Full Investigation</span>
            <ArrowRight className="w-4 h-4 text-slate-950" />
          </button>
        </div>
      </div>

      {/* Main Attribution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Vessel Profile Card & Photograph (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl space-y-4">
            {/* Vessel Header */}
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-extrabold text-white font-display">{vessel.name}</h2>
                  <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 text-[10px] font-mono font-bold border border-red-500/40">
                    High Confidence Match
                  </span>
                </div>
                <div className="text-xs text-slate-400 mt-1 font-mono">
                  IMO: <strong className="text-slate-200">{vessel.imo}</strong> • MMSI: {vessel.mmsi}
                </div>
              </div>

              <div className="text-right font-mono text-xs">
                <div className="text-slate-400">Flag State:</div>
                <div className="font-bold text-cyan-300">{vessel.flag} ({vessel.flagCode})</div>
                <div className="text-[10px] text-slate-500">{vessel.operator}</div>
              </div>
            </div>

            {/* High-detail Vessel Photograph / Graphic */}
            <VesselGraphic
              name={vessel.name}
              imo={vessel.imo}
              flag={vessel.flag}
              operator={vessel.operator}
              className="w-full h-56"
            />

            {/* Evidence Summary with Checkmarks (Matching Reference Screenshot) */}
            <div className="p-4 rounded-xl bg-[#050e1a] border border-slate-800">
              <div className="text-xs font-bold text-slate-200 font-display mb-3 uppercase tracking-wider flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                Evidence Summary
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-slate-300">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Vessel detected in relevant area (<strong className="text-white">2.1 km</strong>)</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Movement pattern matches spill timeline</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>High correlation with spill location & dispersion</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Historical activity & passage route verified</span>
                </div>
              </div>
            </div>

            {/* Supporting Evidence Thumbnails (Matching Reference Screenshot) */}
            <div>
              <div className="text-xs font-bold text-slate-300 font-display mb-2 uppercase tracking-wider">
                Supporting Multi-Source Evidence
              </div>
              <div className="grid grid-cols-3 gap-3">
                {/* 1. Satellite Image */}
                <div className="p-2 rounded-xl bg-[#050e1b] border border-slate-800 hover:border-cyan-500/40 transition-colors">
                  <div className="h-20 rounded-lg bg-slate-900 overflow-hidden relative flex items-center justify-center border border-slate-700">
                    <div className="w-8 h-8 rounded-full bg-slate-700/60 blur-xs" />
                    <span className="absolute bottom-1 right-1 text-[9px] font-mono text-cyan-300 bg-black/70 px-1 rounded">
                      SAR VV
                    </span>
                  </div>
                  <div className="text-[11px] font-semibold text-slate-200 mt-1.5 text-center">
                    Satellite Image
                  </div>
                </div>

                {/* 2. AIS Track */}
                <div className="p-2 rounded-xl bg-[#050e1b] border border-slate-800 hover:border-cyan-500/40 transition-colors">
                  <div className="h-20 rounded-lg bg-slate-900 overflow-hidden relative flex items-center justify-center border border-slate-700">
                    <svg className="w-full h-full" viewBox="0 0 100 60">
                      <line x1="10" y1="50" x2="45" y2="30" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 2" />
                      <line x1="45" y1="30" x2="65" y2="20" stroke="#ef4444" strokeWidth="2.5" />
                      <line x1="65" y1="20" x2="90" y2="10" stroke="#38bdf8" strokeWidth="2" />
                    </svg>
                    <span className="absolute bottom-1 right-1 text-[9px] font-mono text-red-400 bg-black/70 px-1 rounded">
                      AIS GAP
                    </span>
                  </div>
                  <div className="text-[11px] font-semibold text-slate-200 mt-1.5 text-center">
                    AIS Track
                  </div>
                </div>

                {/* 3. Spill Overlay */}
                <div className="p-2 rounded-xl bg-[#050e1b] border border-slate-800 hover:border-cyan-500/40 transition-colors">
                  <div className="h-20 rounded-lg bg-slate-900 overflow-hidden relative flex items-center justify-center border border-slate-700">
                    <div className="w-10 h-7 rounded-full bg-red-600/70 blur-xs" />
                    <div className="w-5 h-4 rounded-full bg-yellow-400/80 blur-xs absolute" />
                    <span className="absolute bottom-1 right-1 text-[9px] font-mono text-yellow-300 bg-black/70 px-1 rounded">
                      MASK
                    </span>
                  </div>
                  <div className="text-[11px] font-semibold text-slate-200 mt-1.5 text-center">
                    Spill Overlay
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Score Gauge & Operational Timeline (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Attribution Score Circular Gauge Card */}
          <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl flex flex-col items-center justify-center text-center">
            <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider mb-2">
              Attribution Analysis
            </span>

            <AttributionGauge
              score={92}
              size={160}
              strokeWidth={12}
              label="Composite AI Probability"
              sublabel="Responsible Vessel"
            />

            <div className="w-full mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="p-2 rounded bg-[#050e1b] border border-slate-800">
                <span className="text-[10px] text-slate-400 block">SPATIAL RANK</span>
                <span className="text-white font-bold">#1 of 27 Vessels</span>
              </div>
              <div className="p-2 rounded bg-[#050e1b] border border-slate-800">
                <span className="text-[10px] text-slate-400 block">AIS INTEGRITY</span>
                <span className="text-red-400 font-bold">40 min Blackout</span>
              </div>
            </div>
          </div>

          {/* Timeline Card matching reference screenshot */}
          <div className="p-5 rounded-2xl bg-[#081527] border border-cyan-500/30 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300 font-display uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-cyan-400" />
                Vessel & Spill Timeline
              </span>
              <span className="text-[10px] font-mono text-cyan-400">Chronological Audit</span>
            </div>

            <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-700">
              {[
                { date: '01 Sep 2026', time: '18:20 UTC', text: 'Vessel enters monitored area', icon: 'blue' },
                { date: '03 Sep 2026', time: '23:47 UTC', text: 'Abnormal movement & deceleration detected', icon: 'amber' },
                { date: '04 Sep 2026', time: '01:12 UTC', text: 'AIS signal blackout at spill origin', icon: 'red' },
                { date: '04 Sep 2026', time: '01:52 UTC', text: 'Vessel reappears 9.8 km down-drift', icon: 'amber' },
                { date: '04 Sep 2026', time: '12:30 UTC', text: 'Satellite SAR image captures oil slick', icon: 'cyan' },
                { date: '04 Sep 2026', time: '13:42 UTC', text: 'Oil spill verified (96.7% confidence)', icon: 'red' },
                { date: '04 Sep 2026', time: '14:15 UTC', text: 'Vessel correlated (92% confidence match)', icon: 'emerald' },
              ].map((ev, i) => (
                <div key={i} className="relative">
                  <div
                    className={`absolute -left-6 top-1 w-2.5 h-2.5 rounded-full ring-4 ring-[#081527] ${
                      ev.icon === 'red'
                        ? 'bg-red-500'
                        : ev.icon === 'amber'
                        ? 'bg-amber-400'
                        : ev.icon === 'emerald'
                        ? 'bg-emerald-400'
                        : 'bg-cyan-400'
                    }`}
                  />
                  <div className="flex items-baseline gap-2">
                    <span className="text-xs font-bold text-white font-mono">{ev.date}</span>
                    <span className="text-[10px] font-mono text-slate-400">{ev.time}</span>
                  </div>
                  <div className="text-xs text-slate-300 mt-0.5">{ev.text}</div>
                </div>
              ))}
            </div>

            <button
              onClick={() => navigate('/investigation-report')}
              className="mt-4 w-full py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer"
            >
              <span>Generate Full Investigation Report</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
