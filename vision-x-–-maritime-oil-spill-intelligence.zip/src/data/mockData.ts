import { SpillIncident, CandidateVessel, SystemAlert, AlertItem, TimelineEvent } from '../types';

export const mockIncidents: SpillIncident[] = [
  {
    id: 'VXN-2026-0001',
    code: 'Spill #001',
    name: 'Arabian Sea Incident #001',
    coordinates: {
      lat: 12.3456,
      lng: 68.7654,
      display: '12.34°N, 68.75°E'
    },
    areaKm2: 12.4,
    confidence: 96.7,
    detectionTime: '04 Sep 2026 13:42 UTC',
    severity: 'High',
    status: 'Under Investigation',
    sensor: 'Sentinel-1 SAR C-Band (VV/VH)',
    modelUsed: 'MobileNetV3 (Custom Maritime-SegNet)',
    estimatedVolumeBarrels: 2450,
    driftDirection: 'East-Southeast (115°)',
    driftSpeedKnots: 1.4
  },
  {
    id: 'VXN-2026-0002',
    code: 'Spill #002',
    name: 'Lakshadweep Passage Drift',
    coordinates: {
      lat: 15.8765,
      lng: 74.3210,
      display: '15.88°N, 74.32°E'
    },
    areaKm2: 8.9,
    confidence: 93.2,
    detectionTime: '03 Sep 2026 09:15 UTC',
    severity: 'Medium',
    status: 'Attributed',
    sensor: 'Sentinel-1 SAR & Landsat-8',
    modelUsed: 'MobileNetV3 (Custom)',
    estimatedVolumeBarrels: 1100,
    driftDirection: 'South-East (130°)',
    driftSpeedKnots: 0.9
  },
  {
    id: 'VXN-2026-0003',
    code: 'Spill #003',
    name: 'Offshore Malabar Coastal Slick',
    coordinates: {
      lat: 13.4101,
      lng: 62.1234,
      display: '13.41°N, 62.12°E'
    },
    areaKm2: 4.7,
    confidence: 88.9,
    detectionTime: '02 Sep 2026 17:32 UTC',
    severity: 'Low',
    status: 'Archived',
    sensor: 'Sentinel-1A SAR',
    modelUsed: 'MobileNetV3 (Custom)',
    estimatedVolumeBarrels: 480,
    driftDirection: 'North-East (045°)',
    driftSpeedKnots: 0.7
  }
];

export const mockCandidateVessels: CandidateVessel[] = [
  {
    rank: 1,
    name: 'MV Ocean Star',
    imo: '9527048',
    mmsi: '636018742',
    flag: 'Liberia',
    flagCode: 'LR',
    operator: 'Oceanic Shipping Ltd.',
    type: 'Crude Oil Tanker (Aframax)',
    distanceKm: 2.1,
    timeMatchPct: 94,
    trackMatchPct: 92,
    aisGapMin: 40,
    attributionScore: 92,
    riskLevel: 'High',
    lastReportedSpeed: '12.4 knots',
    course: '142° (SE)',
    destination: 'Fujairah -> Singapore',
    eta: '09 Sep 2026 04:00 UTC',
    anomalyDetected: 'Deliberate AIS transponder blackout (40 min) preceding slick alignment.'
  },
  {
    rank: 2,
    name: 'Coastal Trader',
    imo: '9147259',
    mmsi: '538006124',
    flag: 'Marshall Islands',
    flagCode: 'MH',
    operator: 'Pacific Blue Lines',
    type: 'Chemical Tanker',
    distanceKm: 4.8,
    timeMatchPct: 76,
    trackMatchPct: 71,
    aisGapMin: 0,
    attributionScore: 71,
    riskLevel: 'Medium',
    lastReportedSpeed: '11.8 knots',
    course: '138°',
    destination: 'Mundra -> Colombo',
    eta: '06 Sep 2026 18:00 UTC',
    anomalyDetected: 'Slight course deflection, no signal drop reported.'
  },
  {
    rank: 3,
    name: 'Blue Horizon',
    imo: '9725410',
    mmsi: '228043000',
    flag: 'Panama',
    flagCode: 'PA',
    operator: 'Horizon Bulk Carriers',
    type: 'Bulk Carrier',
    distanceKm: 8.7,
    timeMatchPct: 42,
    trackMatchPct: 45,
    aisGapMin: 0,
    attributionScore: 42,
    riskLevel: 'Low',
    lastReportedSpeed: '14.1 knots',
    course: '290°',
    destination: 'Jebel Ali -> Port Klang',
    eta: '11 Sep 2026 12:00 UTC',
    anomalyDetected: 'Linear transit along designated sea lane; normal telemetry.'
  },
  {
    rank: 4,
    name: 'Sea Pioneer',
    imo: '9486721',
    mmsi: '354890000',
    flag: 'Malta',
    flagCode: 'MT',
    operator: 'Mediterranean Cargo Corp.',
    type: 'Container Ship',
    distanceKm: 11.3,
    timeMatchPct: 38,
    trackMatchPct: 32,
    aisGapMin: 15,
    attributionScore: 36,
    riskLevel: 'Low',
    lastReportedSpeed: '18.2 knots',
    course: '112°',
    destination: 'Suez -> Jawaharlal Nehru Port',
    eta: '05 Sep 2026 06:30 UTC',
    anomalyDetected: 'Brief telemetry packet loss during monsoon squall.'
  },
  {
    rank: 5,
    name: 'Marlin',
    imo: '9342876',
    mmsi: '636091222',
    flag: 'Liberia',
    flagCode: 'LR',
    operator: 'Atlantic Marine Logistics',
    type: 'LPG Carrier',
    distanceKm: 14.6,
    timeMatchPct: 21,
    trackMatchPct: 27,
    aisGapMin: 0,
    attributionScore: 28,
    riskLevel: 'Low',
    lastReportedSpeed: '15.5 knots',
    course: '085°',
    destination: 'Ras Tanura -> Chennai',
    eta: '07 Sep 2026 21:00 UTC',
    anomalyDetected: 'Far perimeter passage; trajectory incompatible with slick dispersion.'
  }
];

export const mockAlerts: AlertItem[] = [
  {
    id: 'alt-001',
    title: 'High severity oil spill detected in Sector 4',
    description: '12.4 km² estimated area, 96.7% confidence. Multi-spectral radar anomaly detected off commercial tanker corridor.',
    severity: 'High',
    timestamp: 'Today, 14:32 UTC',
    unread: true,
    actionLabel: 'Investigate',
    type: 'oil_spill'
  },
  {
    id: 'alt-002',
    title: 'MV Ocean Star identified as likely source',
    description: '92% attribution score, 2.1 km distance. Vessel exhibits suspicious 40-min AIS blackout and trajectory match.',
    severity: 'High',
    timestamp: 'Today, 14:15 UTC',
    unread: true,
    actionLabel: 'View Details',
    type: 'vessel_attribution'
  },
  {
    id: 'alt-003',
    title: 'Medium spill detected in Sector 2',
    description: '8.7 km² area, 93.2% confidence. Sentinel-1 pass indicates ongoing hydrodynamic drift at 1.1 knots.',
    severity: 'Medium',
    timestamp: 'Today, 09:15 UTC',
    unread: false,
    actionLabel: 'Review',
    type: 'oil_spill'
  },
  {
    id: 'alt-004',
    title: 'AIS signal lost for vessel Coastal Trader',
    description: 'Transponder off for 40 mins while transiting 4.8 km from detected slick origin.',
    severity: 'Medium',
    timestamp: 'Today, 08:30 UTC',
    unread: false,
    actionLabel: 'Track',
    type: 'ais_anomaly'
  },
  {
    id: 'alt-005',
    title: 'Minor sheen detected in Sector 1',
    description: '5.2 km² area, 88.9% confidence. Possible bilge water discharge or natural surfactant dispersion.',
    severity: 'Low',
    timestamp: '02 Sep 2026 17:32 UTC',
    unread: false,
    actionLabel: 'Dismiss',
    type: 'minor_sheen'
  }
];

export const mockOceanStarTimeline: TimelineEvent[] = [
  {
    date: '01 Sep 2026',
    time: '18:20 UTC',
    title: 'Vessel Enters Monitored Sector',
    description: 'MV Ocean Star enters Arabian Sea shipping lane traversing southwest at 13.2 knots.',
    status: 'normal'
  },
  {
    date: '03 Sep 2026',
    time: '23:47 UTC',
    title: 'Abnormal Movement Pattern Detected',
    description: 'Vessel exhibits unexplained 18° deviation from declared passage plan and decelerates to 8.4 knots.',
    status: 'warning'
  },
  {
    date: '04 Sep 2026',
    time: '01:10 UTC',
    title: 'AIS Signal Gap Initiated',
    description: 'Vessel transponder ceases broadcasting for 40 minutes while in immediate proximity to spill origin.',
    status: 'critical'
  },
  {
    date: '04 Sep 2026',
    time: '01:50 UTC',
    title: 'AIS Signal Reacquired',
    description: 'Transponder reappears 9.8 km down-drift, accelerating to 13.9 knots away from slick coordinates.',
    status: 'warning'
  },
  {
    date: '04 Sep 2026',
    time: '12:30 UTC',
    title: 'Satellite SAR Image Captured',
    description: 'Sentinel-1 synthetic aperture radar records 12.4 km² dark hydrocarbon slick with trailing signature.',
    status: 'critical'
  },
  {
    date: '04 Sep 2026',
    time: '13:42 UTC',
    title: 'AI Spill Detection Verified',
    description: 'MobileNetV3 detects oil spill with 96.7% confidence; drift corridor modeled.',
    status: 'critical'
  },
  {
    date: '04 Sep 2026',
    time: '14:15 UTC',
    title: 'AIS Correlation High-Confidence Attribution',
    description: 'MV Ocean Star matched with 92% composite attribution score; investigation dossier compiled.',
    status: 'alert'
  }
];

export const mockDetectionsTrend = [
  { date: '28 Aug', count: 1, confidence: 91 },
  { date: '29 Aug', count: 0, confidence: 0 },
  { date: '30 Aug', count: 2, confidence: 94 },
  { date: '31 Aug', count: 1, confidence: 89 },
  { date: '01 Sep', count: 3, confidence: 95 },
  { date: '02 Sep', count: 2, confidence: 93 },
  { date: '03 Sep', count: 1, confidence: 92 },
  { date: '04 Sep', count: 3, confidence: 97 }
];

export const mockSpillDistribution = [
  { name: 'Small (<5 km²)', count: 7, percentage: 62, color: '#06b6d4' },
  { name: 'Medium (5-15 km²)', count: 3, percentage: 25, color: '#f59e0b' },
  { name: 'Large (>15 km²)', count: 2, percentage: 13, color: '#ef4444' }
];
