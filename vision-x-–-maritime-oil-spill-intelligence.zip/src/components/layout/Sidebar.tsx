import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Satellite, 
  GitBranch, 
  ShieldAlert, 
  Bell, 
  FileText, 
  BarChart3, 
  Settings, 
  Smartphone,
  ChevronRight,
  Sparkles,
  ArrowRight
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const location = useLocation();

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Satellite Analysis', path: '/satellite-analysis', icon: Satellite },
    { name: 'AIS Correlation', path: '/ais-correlation', icon: GitBranch },
    { name: 'Vessel Attribution', path: '/vessel-attribution', icon: ShieldAlert },
    { name: 'Alerts & Notifications', path: '/alerts', icon: Bell },
    { name: 'Investigation Reports', path: '/investigation-report', icon: FileText },
    { name: 'Reports & Analytics', path: '/analytics', icon: BarChart3 },
    { name: 'Settings', path: '/settings', icon: Settings },
    { name: 'Mobile View (Responsive)', path: '/mobile-preview', icon: Smartphone },
  ];

  return (
    <aside className="w-64 bg-[#050b16] border-r border-cyan-500/20 flex flex-col shrink-0 min-h-[calc(100vh-4rem)]">
      {/* Navigation Links */}
      <nav className="p-3 space-y-1 flex-1">
        <div className="px-3 py-2 text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">
          Operational Modules
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all group ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-950/80 to-blue-950/40 text-cyan-200 border border-cyan-500/40 shadow-sm shadow-cyan-500/20 font-semibold'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/60'
                }`
              }
            >
              <div className="flex items-center gap-2.5">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-cyan-300'
                  }`}
                />
                <span>{item.name}</span>
              </div>
              {isActive && (
                <ChevronRight className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Guided Workflow Pill */}
      <div className="p-3 border-t border-slate-800/80">
        <div className="p-3 rounded-xl bg-gradient-to-b from-[#08172c] to-[#040c18] border border-cyan-500/30">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-white flex items-center gap-1 font-display">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              Active Incident
            </span>
            <span className="px-1.5 py-0.5 rounded bg-red-950 text-red-300 text-[9px] font-bold border border-red-500/30">
              Spill #001
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed mb-2.5">
            Attributed to <strong className="text-white">MV Ocean Star</strong> (92% match).
          </p>
          <NavLink
            to="/investigation-report"
            className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 border border-cyan-500/40 text-cyan-200 text-xs font-semibold transition-all text-center"
          >
            <span>View Dossier</span>
            <ArrowRight className="w-3 h-3" />
          </NavLink>
        </div>

        {/* Tagline & Problem Statement Info */}
        <div className="mt-3 px-1 text-center">
          <div className="text-[10px] font-mono text-cyan-400/80 font-semibold tracking-wide">
            VISION X • SIH 2026
          </div>
          <div className="text-[9px] text-slate-500 mt-0.5 font-mono">
            Problem ID: PS26143
          </div>
        </div>
      </div>
    </aside>
  );
};
