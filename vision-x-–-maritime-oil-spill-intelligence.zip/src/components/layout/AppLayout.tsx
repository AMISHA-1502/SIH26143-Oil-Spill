import React, { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Navbar } from './Navbar';
import { Sidebar } from './Sidebar';
import { Menu, X, Shield, Globe } from 'lucide-react';

export const AppLayout: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  // Close mobile menu on route change
  React.useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-[#040914] text-slate-100 flex flex-col">
      {/* Top Navigation */}
      <Navbar onToggleSidebar={() => setMobileMenuOpen(prev => !prev)} />

      {/* Mobile Menu Toggle Bar (Visible on mobile/tablet) */}
      <div className="lg:hidden bg-[#07111f] border-b border-cyan-500/20 px-4 py-2 flex items-center justify-between z-30">
        <button
          onClick={() => setMobileMenuOpen(prev => !prev)}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-semibold text-cyan-300"
        >
          {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>{mobileMenuOpen ? 'Close Menu' : 'Navigation Menu'}</span>
        </button>
        <span className="text-[11px] font-mono text-slate-400">VISION X Console</span>
      </div>

      {/* Main Layout Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Desktop Sidebar */}
        <div className="hidden lg:block">
          <Sidebar />
        </div>

        {/* Mobile Sidebar Overlay Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-50 flex">
            <div 
              className="fixed inset-0 bg-black/70 backdrop-blur-sm"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="relative w-72 max-w-[85vw] bg-[#050b16] z-10 shadow-2xl h-full overflow-y-auto">
              <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                <span className="font-bold text-cyan-300 font-display">VISION X Menu</span>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <Sidebar />
            </div>
          </div>
        )}

        {/* Content View Container */}
        <main className="flex-1 min-w-0 overflow-y-auto bg-[#040914] p-4 lg:p-6 pb-16">
          <Outlet />
        </main>
      </div>

      {/* Footer Banner Matching Reference Screenshots */}
      <footer className="bg-[#03070f] border-t border-cyan-900/40 px-4 lg:px-6 py-2.5 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2 z-20">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px]">
          <span className="text-cyan-400 font-semibold">Cleaner Oceans</span>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <span className="text-slate-300">Safer Navigation</span>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <span className="text-slate-300">Responsible Maritime Operations</span>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <span className="text-emerald-400">A Sustainable Future</span>
        </div>

        <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400">
          <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300">
            SIH 2026
          </span>
          <span>Problem Statement: Maritime Oil Spill Intelligence (PS26143)</span>
        </div>
      </footer>
    </div>
  );
};
