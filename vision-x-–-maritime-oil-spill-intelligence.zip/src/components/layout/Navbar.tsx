import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Radio, 
  Search, 
  Bell, 
  User, 
  CheckCircle2, 
  AlertTriangle, 
  Ship, 
  ShieldCheck, 
  Activity, 
  ChevronRight,
  LogOut
} from 'lucide-react';
import { mockAlerts } from '../../data/mockData';

interface NavbarProps {
  onToggleSidebar?: () => void;
}

export const Navbar: React.FC<NavbarProps> = () => {
  const navigate = useNavigate();
  const unreadAlerts = mockAlerts.filter(a => a.unread).length;

  return (
    <header className="h-16 bg-[#060e1b] border-b border-cyan-500/20 px-4 lg:px-6 flex items-center justify-between sticky top-0 z-40 backdrop-blur-md">
      {/* Brand & Problem Statement ID */}
      <div className="flex items-center gap-4">
        <Link to="/dashboard" className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-700 flex items-center justify-center p-1.5 shadow-lg shadow-cyan-500/20 group-hover:shadow-cyan-400/40 transition-all">
            {/* Eye / Satellite Icon */}
            <svg viewBox="0 0 24 24" className="w-full h-full text-slate-950 stroke-current stroke-2 fill-none">
              <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
              <circle cx="12" cy="12" r="3" className="fill-cyan-100" />
              <circle cx="12" cy="12" r="1" className="fill-slate-950" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-extrabold text-white tracking-wider font-display">VISION X</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                PS26143
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-medium tracking-tight -mt-0.5">
              Maritime Oil Spill Intelligence
            </div>
          </div>
        </Link>
      </div>

      {/* Global Live Operational Status (Matches Reference Screenshot Top Status) */}
      <div className="hidden xl:flex items-center gap-3">
        <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-red-950/40 border border-red-500/30 text-xs text-red-200">
          <AlertTriangle className="w-3.5 h-3.5 text-red-400 animate-pulse" />
          <span><strong className="text-white">3</strong> Active Incidents</span>
        </div>

        <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-blue-950/40 border border-blue-500/30 text-xs text-blue-200">
          <Ship className="w-3.5 h-3.5 text-cyan-400" />
          <span><strong className="text-white">27</strong> Vessels Tracked</span>
        </div>

        <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>System Online</span>
        </div>
      </div>

      {/* Search Bar & Right Controls */}
      <div className="flex items-center gap-3">
        {/* Search Input */}
        <div className="relative hidden md:block w-48 lg:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            placeholder="Search vessel, location, or report..."
            className="w-full bg-[#091526] border border-slate-700/60 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
          />
        </div>

        {/* Timestamp */}
        <div className="hidden lg:flex flex-col text-right">
          <span className="text-[11px] font-mono text-cyan-300 font-semibold">04 Sep 2026</span>
          <span className="text-[10px] font-mono text-slate-400">14:32 UTC</span>
        </div>

        {/* Notifications Icon */}
        <Link
          to="/alerts"
          className="relative p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-cyan-300 transition-colors"
          title="Alerts & Notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadAlerts > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center animate-bounce">
              {unreadAlerts}
            </span>
          )}
        </Link>

        {/* User Profile matching reference: Amisha Shivakumar / Team VISION X */}
        <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white text-xs font-bold ring-1 ring-cyan-400/40">
            AS
          </div>
          <div className="hidden sm:flex flex-col text-left">
            <span className="text-xs font-semibold text-slate-200 leading-tight">Amisha S.</span>
            <span className="text-[10px] text-cyan-400 font-mono">Team VISION X</span>
          </div>
        </div>

        {/* Quick Exit / Logout to Landing */}
        <button
          onClick={() => navigate('/login')}
          title="Sign Out"
          className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-900 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
