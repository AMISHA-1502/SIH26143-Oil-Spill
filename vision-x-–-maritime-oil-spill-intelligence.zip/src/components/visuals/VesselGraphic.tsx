import React from 'react';
import { Ship, Anchor, Flag, ShieldCheck } from 'lucide-react';

interface VesselGraphicProps {
  name?: string;
  imo?: string;
  flag?: string;
  operator?: string;
  className?: string;
}

export const VesselGraphic: React.FC<VesselGraphicProps> = ({
  name = 'MV Ocean Star',
  imo = '9527048',
  flag = 'Liberia',
  operator = 'Oceanic Shipping Ltd.',
  className = 'w-full h-48'
}) => {
  return (
    <div className={`relative rounded-xl overflow-hidden border border-cyan-500/30 bg-[#071322] shadow-xl group ${className}`}>
      {/* Visual illustration of the crude oil tanker at sea */}
      <svg className="w-full h-full" viewBox="0 0 600 320" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="skyGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#0a192f" />
            <stop offset="60%" stopColor="#172a45" />
            <stop offset="100%" stopColor="#203a5e" />
          </linearGradient>

          <linearGradient id="waterGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#0a2540" />
            <stop offset="40%" stopColor="#071b30" />
            <stop offset="100%" stopColor="#040e1a" />
          </linearGradient>

          <linearGradient id="hullGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#1e293b" />
            <stop offset="30%" stopColor="#334155" />
            <stop offset="70%" stopColor="#1e293b" />
            <stop offset="100%" stopColor="#0f172a" />
          </linearGradient>

          <linearGradient id="redBottomGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#7f1d1d" />
            <stop offset="50%" stopColor="#991b1b" />
            <stop offset="100%" stopColor="#450a0a" />
          </linearGradient>
        </defs>

        {/* Sky */}
        <rect width="600" height="200" fill="url(#skyGradient)" />

        {/* Horizon Clouds */}
        <path d="M 0,180 Q 80,165 160,180 T 320,180 T 480,175 T 600,180 L 600,200 L 0,200 Z" fill="#132338" opacity="0.6" />

        {/* Sea Base */}
        <rect y="180" width="600" height="140" fill="url(#waterGradient)" />

        {/* Bow Wave & Vessel Wake */}
        <path d="M 440,235 C 500,240 560,255 600,270 L 600,285 C 540,265 470,250 430,245 Z" fill="#38bdf8" opacity="0.3" />
        <path d="M 120,245 C 70,250 20,265 0,285 L 0,270 C 40,255 90,245 130,240 Z" fill="#38bdf8" opacity="0.4" />

        {/* Tanker Red Antifouling Keel / Lower Hull */}
        <path
          d="M 140,230 L 160,255 L 440,255 L 470,230 Z"
          fill="url(#redBottomGrad)"
        />

        {/* Main Tanker Freeboard / Black Hull */}
        <path
          d="M 130,200 L 140,230 L 470,230 L 485,200 Z"
          fill="url(#hullGrad)"
          stroke="#0f172a"
          strokeWidth="1.5"
        />

        {/* Draft Marks / White Boot-Topping Line */}
        <line x1="139" y1="230" x2="471" y2="230" stroke="#ffffff" strokeWidth="1.5" opacity="0.8" />

        {/* Superstructure / Bridge Tower (Stern Located) */}
        <g transform="translate(160, 140)">
          <rect x="0" y="0" width="65" height="60" fill="#f8fafc" rx="2" />
          <rect x="5" y="10" width="55" height="12" fill="#0f172a" />
          {/* Bridge Windows */}
          <g fill="#38bdf8" opacity="0.85">
            <rect x="8" y="12" width="7" height="8" rx="1" />
            <rect x="18" y="12" width="7" height="8" rx="1" />
            <rect x="28" y="12" width="7" height="8" rx="1" />
            <rect x="38" y="12" width="7" height="8" rx="1" />
            <rect x="48" y="12" width="7" height="8" rx="1" />
          </g>
          {/* Funnel / Exhaust */}
          <rect x="15" y="-20" width="18" height="20" fill="#dc2626" />
          <rect x="15" y="-20" width="18" height="6" fill="#0f172a" />
          {/* Radar Mast */}
          <line x1="45" y1="-25" x2="45" y2="0" stroke="#64748b" strokeWidth="2" />
          <line x1="38" y1="-22" x2="52" y2="-22" stroke="#64748b" strokeWidth="1.5" />
          <line x1="40" y1="-15" x2="50" y2="-15" stroke="#64748b" strokeWidth="1.5" />
        </g>

        {/* Main Deck Piping Manifold & Cargo Tanks */}
        <g transform="translate(230, 192)">
          {/* Deck Pipeline running forward */}
          <line x1="0" y1="5" x2="245" y2="5" stroke="#475569" strokeWidth="4" />
          <line x1="0" y1="2" x2="245" y2="2" stroke="#94a3b8" strokeWidth="1.5" />
          {/* Cargo Domes / Tank Hatches */}
          {[20, 60, 100, 140, 180, 220].map((x) => (
            <rect key={x} x={x} y="1" width="14" height="6" rx="2" fill="#64748b" />
          ))}
          {/* Midship Hose Crane */}
          <line x1="110" y1="5" x2="110" y2="-18" stroke="#cbd5e1" strokeWidth="2" />
          <line x1="110" y1="-18" x2="135" y2="-5" stroke="#cbd5e1" strokeWidth="1.5" />
        </g>

        {/* Bow Crest & Jackstaff */}
        <line x1="485" y1="200" x2="488" y2="182" stroke="#cbd5e1" strokeWidth="1.5" />

        {/* Water Reflections & Ripples */}
        <g stroke="#38bdf8" strokeWidth="1" opacity="0.3">
          <line x1="150" y1="260" x2="450" y2="260" />
          <line x1="180" y1="270" x2="420" y2="270" />
          <line x1="220" y1="280" x2="380" y2="280" />
        </g>
      </svg>

      {/* Info Overlay Badges */}
      <div className="absolute top-3 left-3 flex items-center gap-2">
        <span className="px-2.5 py-1 rounded bg-black/80 backdrop-blur-md text-white text-xs font-bold border border-white/10 flex items-center gap-1.5">
          <Ship className="w-3.5 h-3.5 text-cyan-400" />
          {name}
        </span>
        <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-300 text-[10px] font-mono font-bold border border-red-500/30">
          AFRAMAX CRUDE TANKER
        </span>
      </div>

      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs bg-black/75 backdrop-blur-md px-3 py-2 rounded-lg border border-white/10">
        <div className="flex items-center gap-4 text-slate-300 font-mono text-[11px]">
          <div>IMO: <span className="text-white font-bold">{imo}</span></div>
          <div>Flag: <span className="text-cyan-300 font-bold">{flag}</span></div>
          <div className="hidden sm:inline">Operator: <span className="text-slate-200">{operator}</span></div>
        </div>
        <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 text-[10px] font-bold border border-cyan-500/30">
          HIGH MATCH (92%)
        </span>
      </div>
    </div>
  );
};
