import React, { useState } from 'react';
import { 
  Layers, 
  Compass, 
  Crosshair, 
  Sliders, 
  Maximize2, 
  Clock, 
  ShieldAlert, 
  Ship, 
  Navigation,
  Eye,
  EyeOff,
  Flame,
  Info
} from 'lucide-react';
import { mockIncidents, mockCandidateVessels } from '../../data/mockData';
import { CandidateVessel, SpillIncident } from '../../types';

interface NauticalMapProps {
  onSelectVessel?: (vessel: CandidateVessel) => void;
  onSelectSpill?: (spill: SpillIncident) => void;
  selectedVesselName?: string;
  focusedIncidentId?: string;
  heightClass?: string;
  showTimeScrubber?: boolean;
  compact?: boolean;
}

export const NauticalMap: React.FC<NauticalMapProps> = ({
  onSelectVessel,
  onSelectSpill,
  selectedVesselName = 'MV Ocean Star',
  focusedIncidentId = 'VXN-2026-0001',
  heightClass = 'h-[480px]',
  showTimeScrubber = true,
  compact = false
}) => {
  // Layer toggles matching reference screenshot
  const [layers, setLayers] = useState({
    oilSpill: true,
    aisVessels: true,
    vesselTracks: true,
    driftProjection: true,
    restrictedZones: true,
    satelliteOverlay: false
  });

  const [activeIncident, setActiveIncident] = useState<SpillIncident>(
    mockIncidents.find(i => i.id === focusedIncidentId) || mockIncidents[0]
  );
  const [activeVessel, setActiveVessel] = useState<CandidateVessel | null>(
    mockCandidateVessels.find(v => v.name === selectedVesselName) || mockCandidateVessels[0]
  );
  const [showLayerMenu, setShowLayerMenu] = useState(!compact);
  const [zoom, setZoom] = useState(1);
  const [currentTime, setCurrentTime] = useState('14:32');

  const toggleLayer = (layerKey: keyof typeof layers) => {
    setLayers(prev => ({ ...prev, [layerKey]: !prev[layerKey] }));
  };

  const handleVesselClick = (v: CandidateVessel) => {
    setActiveVessel(v);
    if (onSelectVessel) onSelectVessel(v);
  };

  const handleSpillClick = (s: SpillIncident) => {
    setActiveIncident(s);
    if (onSelectSpill) onSelectSpill(s);
  };

  return (
    <div className={`relative w-full ${heightClass} bg-[#040914] rounded-xl overflow-hidden border border-cyan-500/30 flex flex-col shadow-2xl group select-none`}>
      {/* Top Map Status Bar */}
      <div className="absolute top-3 left-3 z-20 flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/80 backdrop-blur-md border border-cyan-500/40 text-xs text-white shadow-lg">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
          <span className="font-semibold text-cyan-200">ARABIAN SEA MONITORING GRID</span>
          <span className="text-slate-400 font-mono text-[11px] hidden sm:inline">| IN-SZ-04</span>
        </div>

        <div className="px-2.5 py-1.5 rounded-lg bg-slate-950/80 backdrop-blur-md border border-slate-700/60 text-[11px] text-slate-300 font-mono hidden md:flex items-center gap-2">
          <span>CENTER: 12.34°N, 68.75°E</span>
          <span className="text-emerald-400 font-bold">LIVE TELEMETRY</span>
        </div>
      </div>

      {/* Layer Toggle Floating Widget (Matching Reference Map Layers Box) */}
      <div className="absolute top-3 right-3 z-20 flex flex-col items-end gap-2">
        <button
          onClick={() => setShowLayerMenu(prev => !prev)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950/90 backdrop-blur-md border border-cyan-500/40 text-xs font-semibold text-cyan-300 hover:text-white transition-all shadow-md cursor-pointer"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Map Layers</span>
        </button>

        {showLayerMenu && (
          <div className="w-56 p-3 rounded-xl bg-slate-950/95 backdrop-blur-xl border border-cyan-500/30 shadow-2xl text-xs flex flex-col gap-2 transition-all">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              <span>Display Layers</span>
              <span className="text-[10px] text-cyan-400 font-mono">6 active</span>
            </div>

            <label className="flex items-center justify-between cursor-pointer py-1 hover:text-cyan-200">
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]"></span>
                Oil Spill Detection
              </span>
              <input
                type="checkbox"
                checked={layers.oilSpill}
                onChange={() => toggleLayer('oilSpill')}
                className="rounded accent-cyan-500 w-3.5 h-3.5 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer py-1 hover:text-cyan-200">
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]"></span>
                AIS Vessels
              </span>
              <input
                type="checkbox"
                checked={layers.aisVessels}
                onChange={() => toggleLayer('aisVessels')}
                className="rounded accent-cyan-500 w-3.5 h-3.5 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer py-1 hover:text-cyan-200">
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]"></span>
                Vessel Trajectories
              </span>
              <input
                type="checkbox"
                checked={layers.vesselTracks}
                onChange={() => toggleLayer('vesselTracks')}
                className="rounded accent-cyan-500 w-3.5 h-3.5 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer py-1 hover:text-cyan-200">
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]"></span>
                Drift Projection
              </span>
              <input
                type="checkbox"
                checked={layers.driftProjection}
                onChange={() => toggleLayer('driftProjection')}
                className="rounded accent-cyan-500 w-3.5 h-3.5 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer py-1 hover:text-cyan-200">
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-400"></span>
                Restricted Zones (EEZ)
              </span>
              <input
                type="checkbox"
                checked={layers.restrictedZones}
                onChange={() => toggleLayer('restrictedZones')}
                className="rounded accent-cyan-500 w-3.5 h-3.5 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer py-1 hover:text-cyan-200">
              <span className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
                Satellite Imagery
              </span>
              <input
                type="checkbox"
                checked={layers.satelliteOverlay}
                onChange={() => toggleLayer('satelliteOverlay')}
                className="rounded accent-cyan-500 w-3.5 h-3.5 cursor-pointer"
              />
            </label>
          </div>
        )}
      </div>

      {/* Main Vector / SVG Chart Engine */}
      <div className="w-full h-full relative overflow-hidden bg-[#030812]">
        <svg
          viewBox="0 0 1000 600"
          className="w-full h-full preserve-3d"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            {/* Ocean Depth Gradient */}
            <radialGradient id="deepOcean" cx="50%" cy="50%" r="70%">
              <stop offset="0%" stopColor="#08182b" />
              <stop offset="60%" stopColor="#040b15" />
              <stop offset="100%" stopColor="#02060c" />
            </radialGradient>

            {/* Spill Heatmap Radial Filter */}
            <radialGradient id="mapSpillGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ef4444" stopOpacity="0.95" />
              <stop offset="35%" stopColor="#f97316" stopOpacity="0.85" />
              <stop offset="70%" stopColor="#eab308" stopOpacity="0.5" />
              <stop offset="95%" stopColor="#06b6d4" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0" />
            </radialGradient>

            {/* Secondary Spill #002 */}
            <radialGradient id="mapSpillGlow2" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.9" />
              <stop offset="60%" stopColor="#eab308" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0" />
            </radialGradient>

            {/* Drift Corridor Gradient */}
            <linearGradient id="driftGradient" x1="0%" y1="0%" x2="100%" y2="80%">
              <stop offset="0%" stopColor="#ef4444" stopOpacity="0.7" />
              <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.05" />
            </linearGradient>

            {/* Glow Filter */}
            <filter id="vectorGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Deep Sea Base */}
          <rect width="1000" height="600" fill="url(#deepOcean)" />

          {/* Nautical Latitude/Longitude Graticule */}
          <g stroke="rgba(6, 182, 212, 0.08)" strokeWidth="0.8" strokeDasharray="3 3">
            {[100, 200, 300, 400, 500, 600, 700, 800, 900].map(x => (
              <line key={`vert-${x}`} x1={x} y1="0" x2={x} y2="600" />
            ))}
            {[80, 160, 240, 320, 400, 480, 560].map(y => (
              <line key={`horiz-${y}`} x1="0" y1={y} x2="1000" y2={y} />
            ))}
          </g>

          {/* Bathymetry Depth Contours */}
          <path
            d="M 150,0 Q 280,180 340,320 T 480,600"
            fill="none"
            stroke="#0a2540"
            strokeWidth="24"
            opacity="0.25"
          />
          <path
            d="M 650,0 C 720,180 780,240 850,600"
            fill="none"
            stroke="#0a2540"
            strokeWidth="32"
            opacity="0.3"
          />

          {/* Stylized Coastlines (Indian Subcontinent on East, Arabian Peninsula / Horn of Africa on West) */}
          {/* Western Coastline of India */}
          <path
            d="M 780,0 L 800,90 L 820,170 L 835,260 L 850,370 L 880,480 L 920,560 L 960,600 L 1000,600 L 1000,0 Z"
            fill="#081a2e"
            stroke="#0e3a63"
            strokeWidth="1.5"
            opacity="0.8"
          />
          {/* Arabian Peninsula & Horn of Africa */}
          <path
            d="M 0,0 L 220,0 L 200,80 L 160,140 L 90,210 L 40,290 L 80,380 L 140,460 L 90,560 L 0,600 Z"
            fill="#081a2e"
            stroke="#0e3a63"
            strokeWidth="1.5"
            opacity="0.8"
          />

          {/* Coastline Shoreline Glow */}
          <path
            d="M 780,0 L 800,90 L 820,170 L 835,260 L 850,370 L 880,480 L 920,560"
            fill="none"
            stroke="#06b6d4"
            strokeWidth="1"
            opacity="0.4"
            filter="drop-shadow(0 0 6px #06b6d4)"
          />

          {/* EEZ Restricted Boundaries */}
          {layers.restrictedZones && (
            <g stroke="#6366f1" strokeWidth="1" strokeDasharray="6 4" opacity="0.45">
              <path d="M 680,40 C 710,180 730,300 760,460 L 790,600" fill="none" />
              <text x="700" y="240" fill="#818cf8" fontSize="9" fontFamily="monospace" transform="rotate(75, 700, 240)">
                IN-EEZ MARITIME BOUNDARY (200 NM)
              </text>
            </g>
          )}

          {/* International Shipping Lane / Transit Corridor */}
          <path
            d="M 120,140 L 480,280 L 720,440 L 890,560"
            fill="none"
            stroke="#0284c7"
            strokeWidth="1.5"
            strokeDasharray="8 6"
            opacity="0.4"
          />
          <text x="320" y="220" fill="#38bdf8" fontSize="9" fontFamily="monospace" opacity="0.6">
            MAJOR TANKER TRANSIT ROUTE (ARABIAN SEA CORRIDOR)
          </text>

          {/* Drift Corridor Envelope (Spill Dispersion Modeling) */}
          {layers.driftProjection && (
            <g>
              <polygon
                points="490,270 650,340 640,410 470,330"
                fill="url(#driftGradient)"
                opacity="0.35"
              />
              {/* Drift Direction Vector Arrows */}
              <line x1="510" y1="290" x2="620" y2="355" stroke="#f97316" strokeWidth="1.5" strokeDasharray="4 2" />
              <polygon points="625,358 615,350 617,362" fill="#f97316" />
              <text x="545" y="325" fill="#fdba74" fontSize="10" fontFamily="monospace" fontWeight="bold">
                DRIFT: 115° @ 1.4 kts
              </text>
            </g>
          )}

          {/* Detected Oil Spills */}
          {layers.oilSpill && (
            <g>
              {/* Primary Spill #001 (12.34°N, 68.75°E) */}
              <g 
                className="cursor-pointer transition-transform hover:scale-105"
                onClick={() => handleSpillClick(mockIncidents[0])}
              >
                {/* Outer Heatmap Dispersion Polygon */}
                <path
                  d="M 460,260 C 500,240 540,250 560,280 C 580,310 560,340 520,330 C 470,320 440,290 460,260 Z"
                  fill="url(#mapSpillGlow)"
                  filter="url(#vectorGlow)"
                />
                <circle cx="505" cy="285" r="16" fill="#ef4444" opacity="0.8" />
                <circle cx="505" cy="285" r="28" fill="none" stroke="#ef4444" strokeWidth="1.2" strokeDasharray="3 3" className="animate-spin" />

                {/* Spill Callout Marker Label (Matches Reference Screenshot) */}
                <g transform="translate(515, 235)">
                  <rect x="0" y="0" width="125" height="42" rx="6" fill="#081424" stroke="#ef4444" strokeWidth="1.2" filter="drop-shadow(0 4px 12px rgba(0,0,0,0.8))" />
                  <text x="8" y="16" fill="#ffffff" fontSize="11" fontWeight="bold" fontFamily="sans-serif">
                    Spill #001
                  </text>
                  <text x="75" y="16" fill="#ef4444" fontSize="10" fontWeight="bold" fontFamily="sans-serif">
                    96.7%
                  </text>
                  <text x="8" y="30" fill="#94a3b8" fontSize="9" fontFamily="monospace">
                    Area: 12.4 km²
                  </text>
                </g>
              </g>

              {/* Spill #002 Marker */}
              <g 
                className="cursor-pointer"
                onClick={() => handleSpillClick(mockIncidents[1])}
              >
                <circle cx="680" cy="180" r="14" fill="url(#mapSpillGlow2)" />
                <circle cx="680" cy="180" r="4" fill="#f59e0b" />
                <g transform="translate(695, 165)">
                  <rect x="0" y="0" width="95" height="28" rx="4" fill="#081424" stroke="#f59e0b" strokeWidth="1" />
                  <text x="6" y="14" fill="#fef3c7" fontSize="10" fontWeight="bold">Spill #002</text>
                  <text x="6" y="24" fill="#94a3b8" fontSize="8" fontFamily="monospace">8.9 km²</text>
                </g>
              </g>
            </g>
          )}

          {/* AIS Vessel Trajectories & Markers */}
          {layers.vesselTracks && (
            <g>
              {/* MV Ocean Star Track (Suspicious turn and AIS signal gap) */}
              <g>
                <path
                  d="M 380,180 L 440,225 L 470,250"
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="2"
                  strokeDasharray="4 2"
                />
                {/* AIS Gap Red Dashed Section */}
                <path
                  d="M 470,250 L 515,280"
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth="2.5"
                  strokeDasharray="3 3"
                />
                {/* Post-Gap Track */}
                <path
                  d="M 515,280 L 570,310 L 630,340"
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="2"
                />
                {/* Direction Arrows */}
                <polygon points="445,229 435,223 438,232" fill="#38bdf8" />
                <polygon points="575,313 565,307 568,316" fill="#38bdf8" />
              </g>

              {/* Coastal Trader Track */}
              <path
                d="M 320,330 L 420,340 L 530,360 L 680,390"
                fill="none"
                stroke="#10b981"
                strokeWidth="1.2"
                strokeDasharray="4 2"
                opacity="0.6"
              />
              {/* Blue Horizon Track */}
              <path
                d="M 280,210 L 410,230 L 580,260"
                fill="none"
                stroke="#94a3b8"
                strokeWidth="1.2"
                opacity="0.4"
              />
            </g>
          )}

          {/* Candidate Vessels Points */}
          {layers.aisVessels && (
            <g>
              {/* MV Ocean Star (Prime suspect) */}
              <g 
                className="cursor-pointer"
                onClick={() => handleVesselClick(mockCandidateVessels[0])}
                transform="translate(565, 305)"
              >
                <circle cx="0" cy="0" r="14" fill="#ef4444" opacity="0.2" className="animate-ping" />
                <circle cx="0" cy="0" r="5" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
                
                {/* Ship Callout Box */}
                <g transform="translate(10, -22)">
                  <rect x="0" y="0" width="130" height="34" rx="5" fill="#081424" stroke="#ef4444" strokeWidth="1.2" />
                  <text x="8" y="14" fill="#ffffff" fontSize="10" fontWeight="bold">
                    MV Ocean Star
                  </text>
                  <text x="8" y="26" fill="#ef4444" fontSize="9" fontFamily="monospace">
                    IMO: 9527048 | 92% Match
                  </text>
                </g>
              </g>

              {/* Coastal Trader */}
              <g 
                className="cursor-pointer"
                onClick={() => handleVesselClick(mockCandidateVessels[1])}
                transform="translate(530, 360)"
              >
                <circle cx="0" cy="0" r="4.5" fill="#f59e0b" stroke="#ffffff" strokeWidth="1" />
                <text x="8" y="4" fill="#fde68a" fontSize="9" fontWeight="medium">Coastal Trader</text>
              </g>

              {/* Blue Horizon */}
              <g 
                className="cursor-pointer"
                onClick={() => handleVesselClick(mockCandidateVessels[2])}
                transform="translate(410, 230)"
              >
                <circle cx="0" cy="0" r="4" fill="#38bdf8" />
                <text x="8" y="4" fill="#bae6fd" fontSize="9">Blue Horizon</text>
              </g>

              {/* Sea Pioneer */}
              <g 
                className="cursor-pointer"
                onClick={() => handleVesselClick(mockCandidateVessels[3])}
                transform="translate(490, 420)"
              >
                <circle cx="0" cy="0" r="4" fill="#10b981" />
                <text x="8" y="4" fill="#a7f3d0" fontSize="9">Sea Pioneer</text>
              </g>
            </g>
          )}

          {/* Compass Rose */}
          <g transform="translate(60, 520)" opacity="0.6">
            <circle cx="0" cy="0" r="22" fill="none" stroke="#06b6d4" strokeWidth="0.8" />
            <line x1="0" y1="-26" x2="0" y2="26" stroke="#06b6d4" strokeWidth="1.2" />
            <line x1="-26" y1="0" x2="26" y2="0" stroke="#06b6d4" strokeWidth="1.2" />
            <polygon points="0,-24 -4,-12 4,-12" fill="#ef4444" />
            <text x="-3" y="-28" fill="#ef4444" fontSize="10" fontWeight="bold">N</text>
          </g>

          {/* Map Scale */}
          <g transform="translate(860, 560)">
            <rect x="0" y="0" width="100" height="4" fill="#ffffff" opacity="0.8" />
            <text x="35" y="-5" fill="#ffffff" fontSize="9" fontFamily="monospace">50 NM</text>
          </g>
        </svg>

        {/* Selected Vessel Quick HUD on Map */}
        {activeVessel && (
          <div className="absolute bottom-16 left-4 z-20 max-w-xs p-3 rounded-xl bg-slate-950/90 backdrop-blur-md border border-cyan-500/40 shadow-2xl text-xs">
            <div className="flex items-center justify-between gap-2 mb-1">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Ship className="w-3.5 h-3.5 text-cyan-400" />
                {activeVessel.name}
              </span>
              <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-300 font-mono text-[10px] font-bold border border-red-500/30">
                {activeVessel.attributionScore}% MATCH
              </span>
            </div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] text-slate-300 font-mono mt-1.5">
              <div>IMO: {activeVessel.imo}</div>
              <div>Flag: {activeVessel.flag}</div>
              <div>Dist: {activeVessel.distanceKm} km</div>
              <div>AIS Gap: {activeVessel.aisGapMin} min</div>
            </div>
            <div className="text-[10px] text-slate-400 mt-2 border-t border-slate-800 pt-1.5">
              {activeVessel.anomalyDetected}
            </div>
          </div>
        )}
      </div>

      {/* Time Scrubber Bar at Bottom (Matching Reference Screenshot) */}
      {showTimeScrubber && (
        <div className="h-10 bg-[#07111e] border-t border-slate-800 px-4 flex items-center justify-between text-xs z-20">
          <div className="flex items-center gap-2 text-slate-300">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-mono text-cyan-200">04 Sep 2026</span>
            <span className="font-mono font-bold text-white bg-slate-900 px-2 py-0.5 rounded border border-cyan-500/30">
              {currentTime} UTC
            </span>
          </div>

          {/* Interactive scrubber track */}
          <div className="flex-1 mx-6 flex items-center gap-3">
            <span className="text-[10px] font-mono text-slate-500">00:00</span>
            <input
              type="range"
              min="0"
              max="24"
              step="0.5"
              defaultValue="14.5"
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                const hrs = Math.floor(val).toString().padStart(2, '0');
                const mins = val % 1 !== 0 ? '30' : '00';
                setCurrentTime(`${hrs}:${mins}`);
              }}
              className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />
            <span className="text-[10px] font-mono text-slate-500">23:59</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 font-mono text-[10px] border border-emerald-500/30 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              BUFFER: 6h
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
