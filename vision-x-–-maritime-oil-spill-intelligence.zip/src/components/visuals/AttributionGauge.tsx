import React from 'react';

interface AttributionGaugeProps {
  score: number;
  size?: number;
  strokeWidth?: number;
  label?: string;
  sublabel?: string;
}

export const AttributionGauge: React.FC<AttributionGaugeProps> = ({
  score = 92,
  size = 140,
  strokeWidth = 10,
  label = "Attribution Score",
  sublabel = "High Confidence"
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = (score / 100) * circumference;
  const center = size / 2;

  // Score color based on threshold
  const getColor = (val: number) => {
    if (val >= 85) return '#06b6d4'; // High cyan match
    if (val >= 60) return '#f59e0b'; // Amber
    return '#ef4444'; // Red
  };

  const ringColor = getColor(score);

  return (
    <div className="flex flex-col items-center justify-center relative select-none">
      <svg width={size} height={size} className="transform -rotate-90">
        {/* Background track */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          stroke="#13243d"
          strokeWidth={strokeWidth}
          fill="transparent"
        />
        {/* Progress Arc */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          stroke={ringColor}
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={circumference - progress}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
          style={{
            filter: `drop-shadow(0 0 8px ${ringColor}88)`
          }}
        />
      </svg>
      {/* Centered text */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <span className="text-3xl font-extrabold text-white font-display tracking-tight">
          {score}%
        </span>
        <span className="text-[10px] text-cyan-400 font-medium tracking-wide uppercase mt-0.5">
          {sublabel}
        </span>
      </div>
      {label && (
        <span className="text-xs text-slate-400 mt-2 font-medium">
          {label}
        </span>
      )}
    </div>
  );
};
