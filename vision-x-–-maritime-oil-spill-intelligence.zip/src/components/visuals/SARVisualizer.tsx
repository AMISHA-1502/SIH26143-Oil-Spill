import React, { useState, useEffect } from 'react';
import { Sparkles, CheckCircle2, RefreshCw, ZoomIn, ZoomOut, Layers, Eye, Scan, Radio } from 'lucide-react';

interface SARVisualizerProps {
  onRunComplete?: () => void;
  initialMode?: 'comparison' | 'detection-only';
  compact?: boolean;
}

export const SARVisualizer: React.FC<SARVisualizerProps> = ({
  onRunComplete,
  compact = false
}) => {
  const [activeTab, setActiveTab] = useState<'Original' | 'Processed'>('Processed');
  const [isRunning, setIsRunning] = useState(false);
  const [pipelineStep, setPipelineStep] = useState<number>(4); // 0 to 4 (4 = complete)
  const [zoomLevel, setZoomLevel] = useState(1);
  const [showMaskOnly, setShowMaskOnly] = useState(false);

  const runDetectionSimulation = () => {
    setIsRunning(true);
    setPipelineStep(0);

    const step1 = setTimeout(() => setPipelineStep(1), 700);
    const step2 = setTimeout(() => setPipelineStep(2), 1400);
    const step3 = setTimeout(() => setPipelineStep(3), 2200);
    const step4 = setTimeout(() => {
      setPipelineStep(4);
      setIsRunning(false);
      if (onRunComplete) onRunComplete();
    }, 2800);

    return () => {
      clearTimeout(step1);
      clearTimeout(step2);
      clearTimeout(step3);
      clearTimeout(step4);
    };
  };

  return (
    <div className="flex flex-col gap-4">
      {/* View Switcher on smaller headers or tabs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-xs font-mono">
            <Radio className="w-3.5 h-3.5 animate-pulse text-cyan-400" />
            <span>SENTINEL-1 SAR (C-BAND VV/VH)</span>
          </div>
          <span className="text-xs text-slate-400 hidden sm:inline">Orbit 142 • Ascending Pass</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setZoomLevel(prev => Math.max(0.8, prev - 0.2))}
            className="p-1.5 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoomLevel(prev => Math.min(1.6, prev + 0.2))}
            className="p-1.5 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <div className="bg-slate-900/90 p-0.5 rounded-lg border border-slate-700/60 flex text-xs">
            <button
              onClick={() => setActiveTab('Original')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                activeTab === 'Original'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Original
            </button>
            <button
              onClick={() => setActiveTab('Processed')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${
                activeTab === 'Processed'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Processed
            </button>
          </div>
        </div>
      </div>

      {/* Main Image Comparison Canvas / Panels */}
      <div className={`grid ${compact ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-2'} gap-4`}>
        {/* Left: Original SAR Image */}
        {(!compact || activeTab === 'Original') && (
          <div className="relative rounded-xl overflow-hidden border border-cyan-500/20 bg-[#07111e] flex flex-col group shadow-lg">
            <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-black/70 backdrop-blur-md text-slate-200 text-xs font-semibold border border-white/10 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                Original SAR Image
              </span>
              <span className="px-2 py-0.5 rounded bg-blue-950/80 text-blue-300 text-[10px] font-mono border border-blue-500/30">
                SAR
              </span>
            </div>

            <div className="absolute bottom-3 left-3 z-10 text-[11px] font-mono text-slate-400 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded border border-white/10">
              04 Sep 2026 12:30 UTC
            </div>

            {/* Simulated SAR Synthetic Aperture Radar Canvas */}
            <div 
              className="w-full h-80 relative overflow-hidden bg-[#0a1524] select-none flex items-center justify-center"
              style={{ transform: `scale(${zoomLevel})`, transition: 'transform 0.2s ease-out' }}
            >
              <svg className="w-full h-full" viewBox="0 0 600 400" preserveAspectRatio="none">
                <defs>
                  {/* SAR Speckle Pattern */}
                  <filter id="sarSpeckle" x="0%" y="0%" width="100%" height="100%">
                    <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="4" result="noise" />
                    <feColorMatrix type="matrix" values="0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0 0 0 1 0" />
                  </filter>
                  <linearGradient id="oceanGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#0b1726" />
                    <stop offset="50%" stopColor="#12253d" />
                    <stop offset="100%" stopColor="#091422" />
                  </linearGradient>
                </defs>

                {/* Ocean background with radar backscatter roughness */}
                <rect width="600" height="400" fill="url(#oceanGrad)" />
                <rect width="600" height="400" fill="#2d4a6f" opacity="0.18" filter="url(#sarSpeckle)" />

                {/* Graticule grid */}
                <g stroke="rgba(255,255,255,0.06)" strokeWidth="0.8">
                  <line x1="100" y1="0" x2="100" y2="400" />
                  <line x1="200" y1="0" x2="200" y2="400" />
                  <line x1="300" y1="0" x2="300" y2="400" />
                  <line x1="400" y1="0" x2="400" y2="400" />
                  <line x1="500" y1="0" x2="500" y2="400" />
                  <line x1="0" y1="100" x2="600" y2="100" />
                  <line x1="0" y1="200" x2="600" y2="200" />
                  <line x1="0" y1="300" x2="600" y2="300" />
                </g>

                {/* Hydrocarbon Slick Damped Capillary Signature (Dark low backscatter region) */}
                <path
                  d="M 220,130 C 260,110 320,120 370,140 C 430,165 470,210 440,260 C 410,310 330,330 270,300 C 210,270 180,240 190,190 C 195,160 205,140 220,130 Z"
                  fill="#03070d"
                  opacity="0.94"
                />
                {/* Secondary trailing oil streaks */}
                <path
                  d="M 360,250 C 390,290 430,320 480,340 C 500,348 510,360 490,365 C 450,370 410,330 350,280 Z"
                  fill="#040912"
                  opacity="0.85"
                />

                {/* Vessel Radar Bright Return (Point target in SAR) */}
                <circle cx="215" cy="120" r="3.5" fill="#ffffff" filter="drop-shadow(0 0 4px #ffffff)" />
                <path d="M 215,120 L 210,105 L 220,105 Z" fill="#38bdf8" opacity="0.8" />
              </svg>

              {/* Sub-label coordinates */}
              <div className="absolute right-3 top-3 bg-black/60 px-2 py-1 rounded text-[10px] font-mono text-cyan-400 border border-cyan-500/20">
                SAR BACKSCATTER (σ⁰) dB
              </div>
            </div>
          </div>
        )}

        {/* Right: AI Detection Result */}
        {(!compact || activeTab === 'Processed') && (
          <div className="relative rounded-xl overflow-hidden border border-cyan-500/40 bg-[#07111e] flex flex-col group shadow-xl">
            <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-cyan-950/80 backdrop-blur-md text-cyan-200 text-xs font-semibold border border-cyan-500/40 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
                AI Detection Result
              </span>
              <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-300 text-[10px] font-mono border border-red-500/40">
                SAR + Mask
              </span>
            </div>

            <div className="absolute bottom-3 left-3 z-10 text-[11px] font-mono text-slate-300 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded border border-white/10 flex items-center gap-2">
              <span>04 Sep 2026 12:30 UTC</span>
              <span className="text-emerald-400">• High Severity Slick</span>
            </div>

            {/* Thermal/Multispectral segmentation canvas */}
            <div 
              className="w-full h-80 relative overflow-hidden bg-[#060e1b] select-none flex items-center justify-center"
              style={{ transform: `scale(${zoomLevel})`, transition: 'transform 0.2s ease-out' }}
            >
              <svg className="w-full h-full" viewBox="0 0 600 400" preserveAspectRatio="none">
                <defs>
                  {/* Heatmap Gradient for Segmented Spill */}
                  <radialGradient id="spillCoreGrad" cx="50%" cy="50%" r="60%">
                    <stop offset="0%" stopColor="#ef4444" stopOpacity="0.95" />
                    <stop offset="35%" stopColor="#f97316" stopOpacity="0.88" />
                    <stop offset="65%" stopColor="#eab308" stopOpacity="0.75" />
                    <stop offset="88%" stopColor="#06b6d4" stopOpacity="0.55" />
                    <stop offset="100%" stopColor="#0284c7" stopOpacity="0.0" />
                  </radialGradient>

                  <linearGradient id="trailingSlickGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#ef4444" stopOpacity="0.85" />
                    <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.7" />
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.1" />
                  </linearGradient>

                  <filter id="glowEffect" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="6" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>

                {/* Ocean Background */}
                <rect width="600" height="400" fill="#091424" />
                <rect width="600" height="400" fill="#1b2f48" opacity="0.15" />

                {/* Grid Overlay */}
                <g stroke="rgba(6,182,212,0.1)" strokeWidth="0.8">
                  <line x1="100" y1="0" x2="100" y2="400" />
                  <line x1="200" y1="0" x2="200" y2="400" />
                  <line x1="300" y1="0" x2="300" y2="400" />
                  <line x1="400" y1="0" x2="400" y2="400" />
                  <line x1="500" y1="0" x2="500" y2="400" />
                  <line x1="0" y1="100" x2="600" y2="100" />
                  <line x1="0" y1="200" x2="600" y2="200" />
                  <line x1="0" y1="300" x2="600" y2="300" />
                </g>

                {/* AI Detected Spill Segmentation Contour */}
                {pipelineStep >= 3 && (
                  <g filter="url(#glowEffect)">
                    {/* Outer Glow Halo */}
                    <path
                      d="M 210,120 C 255,100 325,110 380,135 C 445,160 485,210 455,270 C 420,325 330,345 265,310 C 200,275 170,240 180,185 C 185,150 195,130 210,120 Z"
                      fill="url(#spillCoreGrad)"
                    />
                    {/* Trail */}
                    <path
                      d="M 360,245 C 395,290 435,325 485,345 C 505,353 515,365 495,370 C 455,375 410,335 345,280 Z"
                      fill="url(#trailingSlickGrad)"
                    />
                    {/* Core dense hydrocarbon cluster */}
                    <ellipse cx="310" cy="205" rx="55" ry="40" fill="#dc2626" opacity="0.9" />
                    <ellipse cx="330" cy="225" rx="35" ry="25" fill="#facc15" opacity="0.95" />
                  </g>
                )}

                {/* Bounding Box & Target Label */}
                {pipelineStep >= 4 && (
                  <g>
                    <rect
                      x="165"
                      y="95"
                      width="350"
                      height="285"
                      fill="none"
                      stroke="#f97316"
                      strokeWidth="1.5"
                      strokeDasharray="4 4"
                      className="animate-pulse"
                    />
                    <g transform="translate(365, 80)">
                      <rect x="0" y="0" width="115" height="22" rx="4" fill="#dc2626" />
                      <text x="8" y="15" fill="#ffffff" fontSize="11" fontWeight="bold" fontFamily="sans-serif">
                        Detected Spill
                      </text>
                    </g>
                  </g>
                )}

                {/* Origin Vessel Point */}
                <circle cx="215" cy="120" r="4.5" fill="#38bdf8" />
                <circle cx="215" cy="120" r="12" fill="none" stroke="#38bdf8" strokeWidth="1" strokeDasharray="2 2" className="animate-spin" />
              </svg>

              {/* Thermal color scale bar on right */}
              <div className="absolute right-3 top-10 bottom-10 w-4 rounded-full bg-gradient-to-t from-blue-600 via-amber-400 to-red-600 border border-white/20 flex flex-col justify-between py-1 px-0.5 text-[8px] font-mono text-white font-bold items-center shadow-lg">
                <span>High</span>
                <span>Med</span>
                <span>Low</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Processing Pipeline Banner */}
      <div className="bg-[#0b172a] rounded-xl border border-cyan-500/20 p-3.5 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-300 font-display tracking-wide uppercase">
              Processing Pipeline
            </span>
            {isRunning && (
              <span className="flex items-center gap-1 text-[11px] text-cyan-400 font-mono animate-pulse">
                <RefreshCw className="w-3 h-3 animate-spin" /> Ingesting & Segmenting...
              </span>
            )}
          </div>
          <button
            onClick={runDetectionSimulation}
            disabled={isRunning}
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md hover:shadow-cyan-500/20 disabled:opacity-50 cursor-pointer"
          >
            {isRunning ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                RUNNING INFERENCE...
              </>
            ) : (
              <>
                <Scan className="w-3.5 h-3.5" />
                RUN DETECTION
              </>
            )}
          </button>
        </div>

        {/* 4 Steps */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { name: 'Image Preprocessing', time: '1.2s', stepIndex: 1 },
            { name: 'Feature Extraction', time: '0.6s', stepIndex: 2 },
            { name: 'Model Inference', time: '0.8s', stepIndex: 3 },
            { name: 'Post Processing', time: '0.2s', stepIndex: 4 },
          ].map((s) => {
            const isDone = pipelineStep >= s.stepIndex;
            const isCurrent = pipelineStep === s.stepIndex - 1 && isRunning;
            return (
              <div
                key={s.name}
                className={`p-2.5 rounded-lg border transition-all flex items-center gap-2.5 ${
                  isDone
                    ? 'bg-cyan-950/40 border-cyan-500/40 text-cyan-200'
                    : isCurrent
                    ? 'bg-blue-950/60 border-cyan-400 text-white animate-pulse'
                    : 'bg-slate-900/60 border-slate-800 text-slate-500'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                    isDone
                      ? 'bg-cyan-500 text-slate-950'
                      : isCurrent
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {isDone ? <CheckCircle2 className="w-3.5 h-3.5" /> : s.stepIndex}
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] font-semibold truncate">{s.name}</div>
                  <div className="text-[10px] font-mono text-slate-400">{s.time}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
