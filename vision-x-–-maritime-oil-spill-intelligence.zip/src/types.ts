export interface SpillIncident {
  id: string;
  code: string;
  name: string;
  coordinates: {
    lat: number;
    lng: number;
    display: string;
  };
  areaKm2: number;
  confidence: number;
  detectionTime: string;
  severity: 'High' | 'Medium' | 'Low';
  status: 'Under Investigation' | 'Attributed' | 'Archived' | 'New';
  sensor: string;
  modelUsed: string;
  estimatedVolumeBarrels?: number;
  driftDirection?: string;
  driftSpeedKnots?: number;
}

export interface CandidateVessel {
  rank: number;
  name: string;
  imo: string;
  mmsi: string;
  flag: string;
  flagCode: string;
  operator: string;
  type: string;
  distanceKm: number;
  timeMatchPct: number;
  trackMatchPct: number;
  aisGapMin: number;
  attributionScore: number;
  riskLevel: 'High' | 'Medium' | 'Low';
  lastReportedSpeed: string;
  course: string;
  destination: string;
  eta: string;
  anomalyDetected: string;
  photoUrl?: string;
}

export interface SystemAlert {
  id: string;
  title: string;
  message: string;
  severity: 'High' | 'Medium' | 'Low' | 'Info';
  timestamp: string;
  timeAgo: string;
  relatedId?: string;
  read: boolean;
  category: 'Spill' | 'Vessel' | 'Correlation' | 'System' | 'Report';
}

export interface AlertItem {
  id: string;
  title: string;
  description: string;
  severity: 'High' | 'Medium' | 'Low';
  timestamp: string;
  unread: boolean;
  actionLabel: string;
  type: 'oil_spill' | 'vessel_attribution' | 'ais_anomaly' | 'minor_sheen';
}

export interface DetectionStep {
  name: string;
  duration: string;
  status: 'pending' | 'running' | 'completed';
}

export interface TimelineEvent {
  time: string;
  date: string;
  title: string;
  description: string;
  status: 'normal' | 'warning' | 'critical' | 'alert';
}
