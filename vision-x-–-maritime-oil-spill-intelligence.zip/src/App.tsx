import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppLayout } from './components/layout/AppLayout';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { SatelliteAnalysisPage } from './pages/SatelliteAnalysisPage';
import { AISCorrelationPage } from './pages/AISCorrelationPage';
import { VesselAttributionPage } from './pages/VesselAttributionPage';
import { AlertsPage } from './pages/AlertsPage';
import { InvestigationReportPage } from './pages/InvestigationReportPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { SettingsPage } from './pages/SettingsPage';
import { MobilePreviewPage } from './pages/MobilePreviewPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Marketing & Authentication Screens */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />

        {/* Operational Intelligence Application Console (Protected Layout) */}
        <Route element={<AppLayout />}>
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/satellite-analysis" element={<SatelliteAnalysisPage />} />
          <Route path="/ais-correlation" element={<AISCorrelationPage />} />
          <Route path="/vessel-attribution" element={<VesselAttributionPage />} />
          <Route path="/alerts" element={<AlertsPage />} />
          <Route path="/investigation-report" element={<InvestigationReportPage />} />
          <Route path="/analytics" element={<AnalyticsPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/mobile-preview" element={<MobilePreviewPage />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
